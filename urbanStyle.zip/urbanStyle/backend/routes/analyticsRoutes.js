const express = require("express");
const feedbackService = require("../services/feedbackService");
const { analyzeFeedback } = require("../services/aiService");
const { attachUser, allowRoles } = require("../middleware/roleMiddleware");

const router = express.Router();

/**
 * Get analytics summary
 */
router.get(
  "/summary",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  (req, res) => {
    try {
      let feedback = feedbackService.readFeedback();

      if (req.user.role === "MANAGER") {
        feedback = feedbackService.filterByStore(req.user.store);
      }

      const analysis = analyzeFeedback(feedback);
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Error generating analytics", error: error.message });
    }
  }
);

/**
 * Get store-wise breakdown
 */
router.get(
  "/stores",
  attachUser,
  allowRoles("ADMIN", "CX"),
  (req, res) => {
    try {
      const feedback = feedbackService.readFeedback();
      const analysis = analyzeFeedback(feedback);
      res.json(analysis.storeAnalysis);
    } catch (error) {
      res.status(500).json({ message: "Error fetching store analytics", error: error.message });
    }
  }
);

/**
 * Get product-wise breakdown
 */
router.get(
  "/products",
  attachUser,
  allowRoles("ADMIN", "CX"),
  (req, res) => {
    try {
      const feedback = feedbackService.readFeedback();
      const analysis = analyzeFeedback(feedback);
      res.json(analysis.productAnalysis);
    } catch (error) {
      res.status(500).json({ message: "Error fetching product analytics", error: error.message });
    }
  }
);

/**
 * Get rating distribution
 */
router.get(
  "/ratings",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  (req, res) => {
    try {
      let feedback = feedbackService.readFeedback();

      if (req.user.role === "MANAGER") {
        feedback = feedbackService.filterByStore(req.user.store);
      }

      const analysis = analyzeFeedback(feedback);
      res.json(analysis.ratingDistribution);
    } catch (error) {
      res.status(500).json({ message: "Error fetching rating distribution", error: error.message });
    }
  }
);

module.exports = router;
