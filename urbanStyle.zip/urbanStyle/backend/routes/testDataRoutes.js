const express = require("express");
const fs = require("fs");
const path = require("path");
const feedbackService = require("../services/feedbackService");
const { attachUser, allowRoles } = require("../middleware/roleMiddleware");

const router = express.Router();

/**
 * Load test data with customer emails
 * POST /test-data/load
 */
router.post(
  "/load",
  attachUser,
  allowRoles("ADMIN"),
  (req, res) => {
    try {
      const testDataPath = path.join(__dirname, "../data/test-feedback-with-emails.json");
      
      if (!fs.existsSync(testDataPath)) {
        return res.status(404).json({ message: "Test data file not found" });
      }

      const testData = JSON.parse(fs.readFileSync(testDataPath, "utf8"));
      
      // Add test data to feedback
      feedbackService.addFeedback(testData);

      res.json({
        success: true,
        message: `Loaded ${testData.length} test feedback entries with customer emails`,
        count: testData.length,
      });
    } catch (error) {
      console.error("Error loading test data:", error);
      res.status(500).json({ 
        message: "Error loading test data", 
        error: error.message 
      });
    }
  }
);

module.exports = router;

