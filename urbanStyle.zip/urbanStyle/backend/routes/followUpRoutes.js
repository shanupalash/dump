const express = require("express");
const { sendFollowUpEmail, generateFollowUpEmail } = require("../services/emailService");
const followUpService = require("../services/followUpService");
const feedbackService = require("../services/feedbackService");
const { attachUser, allowRoles } = require("../middleware/roleMiddleware");

const router = express.Router();

/**
 * Send follow-up email to customer
 * POST /followup/send
 */
router.post(
  "/send",
  attachUser,
  allowRoles("ADMIN", "MANAGER", "CX"),
  async (req, res) => {
    try {
      const { feedbackId, subject, body, html, customMessage } = req.body;

      if (!feedbackId) {
        return res.status(400).json({ message: "Feedback ID is required" });
      }

      const feedback = feedbackService.getFeedbackById(feedbackId);
      if (!feedback) {
        return res.status(404).json({ message: "Feedback not found" });
      }

      if (!feedback.customerEmail) {
        return res.status(400).json({ 
          message: "Customer email not available for this feedback" 
        });
      }

      // Check if manager can access this store's feedback
      if (req.user.role === "MANAGER" && feedback.store !== req.user.store) {
        return res.status(403).json({ message: "Access denied" });
      }

      const managerName = req.user.username || "Store Manager";
      const storeName = feedback.store;

      // Use provided email content or generate default
      let emailSubject, emailBody, emailHtml;
      
      if (subject && body) {
        emailSubject = subject;
        emailBody = body;
        emailHtml = html || body.replace(/\n/g, "<br>");
      } else {
        // Generate default email
        const emailContent = generateFollowUpEmail(feedback, managerName, storeName);
        emailSubject = emailContent.subject;
        emailBody = emailContent.text;
        emailHtml = emailContent.html;
      }

      // Send email using email service
      const emailResult = await sendFollowUpEmail(
        feedback, 
        managerName, 
        storeName,
        emailSubject,
        emailBody,
        emailHtml
      );

      // Create follow-up record
      const followUp = followUpService.createFollowUp({
        feedbackId: feedbackId,
        customerEmail: feedback.customerEmail,
        customerName: feedback.customerName || "Customer",
        store: feedback.store,
        sentBy: req.user.username,
        sentByRole: req.user.role,
        customMessage: customMessage || "",
        emailSubject: emailSubject,
        emailBody: emailBody,
        emailResult: emailResult,
      });

      res.json({
        success: true,
        message: "Follow-up email sent successfully",
        followUp: followUp,
        emailMode: emailResult.mode,
      });
    } catch (error) {
      console.error("Follow-up error:", error);
      res.status(500).json({ 
        message: "Error sending follow-up email", 
        error: error.message 
      });
    }
  }
);

/**
 * Get follow-ups for a specific feedback
 * GET /followup/feedback/:feedbackId
 */
router.get(
  "/feedback/:feedbackId",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  (req, res) => {
    try {
      const feedback = feedbackService.getFeedbackById(req.params.feedbackId);
      
      if (!feedback) {
        return res.status(404).json({ message: "Feedback not found" });
      }

      // Check if manager can access this store's feedback
      if (req.user.role === "MANAGER" && feedback.store !== req.user.store) {
        return res.status(403).json({ message: "Access denied" });
      }

      const followUps = followUpService.getFollowUpsByFeedbackId(req.params.feedbackId);
      res.json(followUps);
    } catch (error) {
      res.status(500).json({ 
        message: "Error fetching follow-ups", 
        error: error.message 
      });
    }
  }
);

/**
 * Get all follow-ups (Admin/CX only, or Manager's store only)
 * GET /followup
 */
router.get(
  "/",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  (req, res) => {
    try {
      let followUps;
      
      if (req.user.role === "MANAGER") {
        followUps = followUpService.getFollowUpsByStore(req.user.store);
      } else {
        followUps = followUpService.getAllFollowUps();
      }

      // Sort by date, newest first
      followUps.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

      res.json(followUps);
    } catch (error) {
      res.status(500).json({ 
        message: "Error fetching follow-ups", 
        error: error.message 
      });
    }
  }
);

/**
 * Update follow-up status
 * PUT /followup/:id/status
 */
router.put(
  "/:id/status",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  (req, res) => {
    try {
      const { status, notes } = req.body;
      const followUp = followUpService.getFollowUpById(req.params.id);

      if (!followUp) {
        return res.status(404).json({ message: "Follow-up not found" });
      }

      // Check if manager can access this follow-up
      if (req.user.role === "MANAGER" && followUp.store !== req.user.store) {
        return res.status(403).json({ message: "Access denied" });
      }

      const validStatuses = ["sent", "replied", "resolved", "closed"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ 
          message: `Invalid status. Must be one of: ${validStatuses.join(", ")}` 
        });
      }

      const updated = followUpService.updateFollowUpStatus(
        req.params.id,
        status,
        notes
      );

      res.json({
        message: "Follow-up status updated",
        followUp: updated,
      });
    } catch (error) {
      res.status(500).json({ 
        message: "Error updating follow-up status", 
        error: error.message 
      });
    }
  }
);

/**
 * Get follow-up statistics
 * GET /followup/stats
 */
router.get(
  "/stats",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  (req, res) => {
    try {
      let followUps;
      
      if (req.user.role === "MANAGER") {
        followUps = followUpService.getFollowUpsByStore(req.user.store);
      } else {
        followUps = followUpService.getAllFollowUps();
      }

      const stats = {
        total: followUps.length,
        sent: followUps.filter(fu => fu.status === "sent").length,
        replied: followUps.filter(fu => fu.status === "replied").length,
        resolved: followUps.filter(fu => fu.status === "resolved").length,
        closed: followUps.filter(fu => fu.status === "closed").length,
        byStore: {},
      };

      followUps.forEach(fu => {
        stats.byStore[fu.store] = (stats.byStore[fu.store] || 0) + 1;
      });

      res.json(stats);
    } catch (error) {
      res.status(500).json({ 
        message: "Error fetching follow-up statistics", 
        error: error.message 
      });
    }
  }
);

module.exports = router;

