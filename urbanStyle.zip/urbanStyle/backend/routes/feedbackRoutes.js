const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const parseCSV = require("../services/csvService");
const feedbackService = require("../services/feedbackService");
const { allowRoles, attachUser } = require("../middleware/roleMiddleware");
const { generateResponse } = require("../services/aiService");
const { autoCategorizeFeedback } = require("../services/aiService");

const router = express.Router();

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext === ".csv" || ext === ".json") {
      cb(null, true);
    } else {
      cb(new Error("Only CSV and JSON files are allowed"));
    }
  },
});

/**
 * Upload feedback CSV/JSON
 * ADMIN only
 */
router.post(
  "/upload",
  attachUser,
  allowRoles("ADMIN"),
  upload.single("file"),
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const filePath = req.file.path;
      const ext = path.extname(req.file.originalname).toLowerCase();
      let data = [];

      if (ext === ".csv") {
        data = await parseCSV(filePath);
      } else if (ext === ".json") {
        const fileContent = fs.readFileSync(filePath, "utf8");
        const jsonData = JSON.parse(fileContent);
        data = Array.isArray(jsonData) ? jsonData : [jsonData];
        // Ensure all items have required fields
        data = data.map((item) => ({
          id: item.id || `FB${Date.now()}${Math.floor(Math.random() * 1000)}`,
          store: item.store || "Unknown",
          channel: item.channel || "Microsoft Form",
          product: item.product || "General",
          rating: Number(item.rating) || 3,
          comment: item.comment || "",
          customerName: item.customerName || item.name || "",
          customerEmail: item.customerEmail || item.email || "",
          createdAt: item.createdAt || new Date().toISOString().split("T")[0],
        }));
      }

      // Clean up uploaded file
      fs.unlinkSync(filePath);

      feedbackService.addFeedback(data);
      res.json({
        message: "Feedback uploaded successfully",
        count: data.length,
      });
    } catch (error) {
      res
        .status(500)
        .json({ message: "Error processing file", error: error.message });
    }
  }
);

/**
 * Get feedback
 * ADMIN, CX → all
 * MANAGER → only own store
 */
router.get(
  "/",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  (req, res) => {
    try {
      let feedback = feedbackService.readFeedback();

      if (req.user.role === "MANAGER") {
        feedback = feedbackService.filterByStore(req.user.store);
      }

      // Sort by date, newest first
      feedback.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

      res.json(feedback);
    } catch (error) {
      res
        .status(500)
        .json({ message: "Error fetching feedback", error: error.message });
    }
  }
);

/**
 * Get single feedback item
 */
router.get(
  "/:id",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  async (req, res) => {
    try {
      const feedback = feedbackService.getFeedbackById(req.params.id);

      if (!feedback) {
        return res.status(404).json({ message: "Feedback not found" });
      }

      // Check if manager can access this store's feedback
      if (req.user.role === "MANAGER" && feedback.store !== req.user.store) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Generate AI response and category
      const [suggestedResponse, category] = await Promise.all([
        generateResponse(feedback),
        autoCategorizeFeedback(feedback),
      ]);

      res.json({ ...feedback, suggestedResponse, category });
    } catch (error) {
      res
        .status(500)
        .json({ message: "Error fetching feedback", error: error.message });
    }
  }
);

/**
 * Add new feedback manually
 */
router.post("/", attachUser, allowRoles("ADMIN", "CX"), (req, res) => {
  try {
    const { store, channel, product, rating, comment } = req.body;

    if (!store || !rating || !comment) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    const newFeedback = {
      id: `FB${Date.now()}${Math.floor(Math.random() * 1000)}`,
      store,
      channel: channel || "Manual Entry",
      product: product || "General",
      rating: Number(rating),
      comment,
      customerName: req.body.customerName || req.body.name || "",
      customerEmail: req.body.customerEmail || req.body.email || "",
      createdAt: new Date().toISOString().split("T")[0],
    };

    feedbackService.addFeedback([newFeedback]);
    res.json({ message: "Feedback added", feedback: newFeedback });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error adding feedback", error: error.message });
  }
});

module.exports = router;
