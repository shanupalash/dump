const express = require("express");
const { chatWithAI, suggestResolutions, autoCategorizeFeedback, analyzeSentiment } = require("../services/aiService");
const feedbackService = require("../services/feedbackService");
const { attachUser, allowRoles } = require("../middleware/roleMiddleware");

const router = express.Router();

/**
 * AI Chatbot endpoint
 * POST /ai/chat
 */
router.post(
  "/chat",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  async (req, res) => {
    try {
      const { question } = req.body;

      if (!question || question.trim().length === 0) {
        return res.status(400).json({ message: "Question is required" });
      }

      // Get context based on user role
      let context = {};
      if (req.user.role === "MANAGER") {
        context.store = req.user.store;
      }

      const response = await chatWithAI(question, context);
      
      res.json({
        question,
        response,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ 
        message: "Error processing chat request", 
        error: error.message 
      });
    }
  }
);

/**
 * Get resolution suggestions for a feedback
 * GET /ai/resolutions/:feedbackId
 */
router.get(
  "/resolutions/:feedbackId",
  attachUser,
  allowRoles("ADMIN", "CX", "MANAGER"),
  async (req, res) => {
    try {
      const feedback = feedbackService.getFeedbackById(req.params.feedbackId);
      
      if (!feedback) {
        return res.status(404).json({ message: "Feedback not found" });
      }

      // Check if manager can access this store's feedback
      if (req.user.role === "MANAGER" && feedback.store !== req.user.store) {
        return res.status(403).json({ message: "Access denied" });
      }

      const resolutions = await suggestResolutions(req.params.feedbackId);
      
      res.json({
        feedbackId: req.params.feedbackId,
        resolutions,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("Resolution suggestion error:", error);
      res.status(500).json({ 
        message: "Error generating resolutions", 
        error: error.message 
      });
    }
  }
);

/**
 * Auto-categorize feedback
 * POST /ai/categorize
 */
router.post(
  "/categorize",
  attachUser,
  allowRoles("ADMIN", "CX"),
  async (req, res) => {
    try {
      const { feedbackId, comment } = req.body;

      if (!comment && !feedbackId) {
        return res.status(400).json({ message: "Comment or feedbackId is required" });
      }

      let feedback;
      if (feedbackId) {
        feedback = feedbackService.getFeedbackById(feedbackId);
        if (!feedback) {
          return res.status(404).json({ message: "Feedback not found" });
        }
      } else {
        feedback = { comment };
      }

      const category = await autoCategorizeFeedback(feedback);
      
      res.json({
        category,
        feedbackId: feedbackId || null,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("Categorization error:", error);
      res.status(500).json({ 
        message: "Error categorizing feedback", 
        error: error.message 
      });
    }
  }
);

/**
 * Batch analyze feedback with AI
 * POST /ai/batch-analyze
 */
router.post(
  "/batch-analyze",
  attachUser,
  allowRoles("ADMIN", "CX"),
  async (req, res) => {
    try {
      const { feedbackIds } = req.body;

      if (!feedbackIds || !Array.isArray(feedbackIds)) {
        return res.status(400).json({ message: "feedbackIds array is required" });
      }

      const results = [];
      for (const id of feedbackIds.slice(0, 10)) { // Limit to 10 for performance
        const feedback = feedbackService.getFeedbackById(id);
        if (feedback) {
          const category = await autoCategorizeFeedback(feedback);
          const sentiment = await analyzeSentiment(feedback.comment);
          results.push({
            id,
            category,
            sentiment,
          });
        }
      }

      res.json({
        results,
        total: results.length,
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      console.error("Batch analysis error:", error);
      res.status(500).json({ 
        message: "Error in batch analysis", 
        error: error.message 
      });
    }
  }
);

module.exports = router;

