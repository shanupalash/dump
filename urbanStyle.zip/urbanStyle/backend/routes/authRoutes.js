const express = require("express");
const fs = require("fs");
const path = require("path");
const users = require("../data/users.json");
const router = express.Router();

router.post("/login", (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ message: "Username and password required" });
    }
    
    const user = users.find(
      (u) => u.username === username && u.password === password
    );
    
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    
    // Return user without password
    const { password: _, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  } catch (error) {
    res.status(500).json({ message: "Login error", error: error.message });
  }
});

router.get("/me", (req, res) => {
  // This would typically verify a token, but for prototype we'll use headers
  const username = req.headers["x-username"];
  const role = req.headers["x-role"];
  
  if (!username || !role) {
    return res.status(401).json({ message: "Not authenticated" });
  }
  
  const user = users.find(u => u.username === username);
  if (!user) {
    return res.status(401).json({ message: "User not found" });
  }
  
  const { password: _, ...userWithoutPassword } = user;
  res.json(userWithoutPassword);
});

module.exports = router;
