function allowRoles(...roles) {
  return (req, res, next) => {
    const userRole = req.user?.role || req.headers["x-role"];
    if (!userRole || !roles.includes(userRole)) {
      return res.status(403).json({ message: "Access denied" });
    }
    next();
  };
}

function attachUser(req, res, next) {
  // Try to get user from token/header, or from session
  const role = req.headers["x-role"];
  const store = req.headers["x-store"];
  const username = req.headers["x-username"];
  
  if (role) {
    req.user = {
      role,
      store,
      username,
    };
  }
  
  next();
}

module.exports = { allowRoles, attachUser };
