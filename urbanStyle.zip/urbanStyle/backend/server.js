const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/authRoutes");
const feedbackRoutes = require("./routes/feedbackRoutes");
const analyticsRoutes = require("./routes/analyticsRoutes");
const aiRoutes = require("./routes/aiRoutes");
const followUpRoutes = require("./routes/followUpRoutes");
const testDataRoutes = require("./routes/testDataRoutes");

const app = express();
app.use(cors());
app.use(express.json());

app.use("/auth", authRoutes);
app.use("/feedback", feedbackRoutes);
app.use("/analytics", analyticsRoutes);
app.use("/ai", aiRoutes);
app.use("/followup", followUpRoutes);
app.use("/test-data", testDataRoutes);

app.listen(5000, () => {
  console.log("Backend running on http://localhost:5000");
});
