const fs = require("fs");
const path = require("path");

const DATA_FILE = path.join(__dirname, "../data/feedback.json");

function readFeedback() {
  try {
    const data = fs.readFileSync(DATA_FILE, "utf8");
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

function writeFeedback(feedback) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(feedback, null, 2));
}

function addFeedback(newFeedback) {
  const feedback = readFeedback();
  const updated = [...feedback, ...newFeedback];
  writeFeedback(updated);
  return updated;
}

function filterByStore(storeName) {
  const feedback = readFeedback();
  return feedback.filter((f) => f.store === storeName);
}

function getFeedbackById(id) {
  const feedback = readFeedback();
  return feedback.find((f) => f.id === id);
}

function updateFeedback(id, updates) {
  const feedback = readFeedback();
  const index = feedback.findIndex((f) => f.id === id);
  if (index !== -1) {
    feedback[index] = { ...feedback[index], ...updates };
    writeFeedback(feedback);
    return feedback[index];
  }
  return null;
}

module.exports = {
  readFeedback,
  addFeedback,
  filterByStore,
  getFeedbackById,
  updateFeedback,
  writeFeedback,
};
