const fs = require("fs");
const path = require("path");

const DATA_FILE = path.join(__dirname, "../data/followUps.json");

function readFollowUps() {
  try {
    const data = fs.readFileSync(DATA_FILE, "utf8");
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

function writeFollowUps(followUps) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(followUps, null, 2));
}

function createFollowUp(followUpData) {
  const followUps = readFollowUps();
  const newFollowUp = {
    id: `FU${Date.now()}${Math.floor(Math.random() * 1000)}`,
    ...followUpData,
    createdAt: new Date().toISOString(),
    status: "sent", // sent, replied, resolved
  };
  followUps.push(newFollowUp);
  writeFollowUps(followUps);
  return newFollowUp;
}

function getFollowUpsByFeedbackId(feedbackId) {
  const followUps = readFollowUps();
  return followUps.filter(fu => fu.feedbackId === feedbackId);
}

function getFollowUpsByStore(storeName) {
  const followUps = readFollowUps();
  return followUps.filter(fu => fu.store === storeName);
}

function getAllFollowUps() {
  return readFollowUps();
}

function updateFollowUpStatus(followUpId, status, notes = "") {
  const followUps = readFollowUps();
  const index = followUps.findIndex(fu => fu.id === followUpId);
  if (index !== -1) {
    followUps[index].status = status;
    followUps[index].notes = notes;
    followUps[index].updatedAt = new Date().toISOString();
    writeFollowUps(followUps);
    return followUps[index];
  }
  return null;
}

function getFollowUpById(id) {
  const followUps = readFollowUps();
  return followUps.find(fu => fu.id === id);
}

module.exports = {
  createFollowUp,
  getFollowUpsByFeedbackId,
  getFollowUpsByStore,
  getAllFollowUps,
  updateFollowUpStatus,
  getFollowUpById,
};

