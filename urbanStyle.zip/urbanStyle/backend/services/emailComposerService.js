const { chatWithAI } = require("./aiService");
const feedbackService = require("./feedbackService");

// Generate email content using AI
async function generateEmailContent(feedback, emailType = "followup", customInstructions = "") {
  const customerName = feedback.customerName || "Valued Customer";
  const isNegative = feedback.rating <= 2;
  
  const prompt = `Generate a professional follow-up email for a retail customer feedback scenario.

Customer Details:
- Name: ${customerName}
- Store: ${feedback.store}
- Product: ${feedback.product || "General"}
- Rating: ${feedback.rating}/5
- Feedback: ${feedback.comment}

Email Type: ${emailType}
${isNegative ? "This is negative feedback - the email should be apologetic and solution-focused." : "This is positive feedback - the email should be appreciative and encouraging."}

${customInstructions ? `Additional Instructions: ${customInstructions}` : ""}

Generate a professional, empathetic email that:
1. Addresses the customer by name
2. Acknowledges their feedback appropriately
3. Shows genuine concern (for negative) or appreciation (for positive)
4. Asks for more details about their experience
5. Offers to help resolve issues (for negative)
6. Maintains a professional yet warm tone
7. Includes a clear call to action

Format the response as:
SUBJECT: [email subject line]
BODY: [email body content]`;

  try {
    const aiResponse = await chatWithAI(prompt);
    
    // Parse AI response to extract subject and body
    const subjectMatch = aiResponse.match(/SUBJECT:\s*(.+?)(?:\n|$)/i);
    const bodyMatch = aiResponse.match(/BODY:\s*([\s\S]+?)(?:\n\n|$)/i) || 
                     aiResponse.match(/BODY:\s*([\s\S]+)/i);
    
    const subject = subjectMatch 
      ? subjectMatch[1].trim() 
      : isNegative 
        ? `Follow-up on Your Feedback - ${feedback.store} Store`
        : `Thank You for Your Feedback - ${feedback.store} Store`;
    
    const body = bodyMatch 
      ? bodyMatch[1].trim() 
      : aiResponse.replace(/SUBJECT:.*?\n/i, "").replace(/BODY:\s*/i, "").trim();
    
    return {
      subject,
      body,
      html: convertToHTML(body, customerName, feedback.store),
    };
  } catch (error) {
    console.error("AI email generation error:", error);
    return generateFallbackEmail(feedback, emailType);
  }
}

// Convert plain text to HTML
function convertToHTML(body, customerName, storeName) {
  // Split into paragraphs
  const paragraphs = body.split(/\n\n+/).filter(p => p.trim());
  
  let html = `
    <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto;">
      <div style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0;">
        <h2 style="margin: 0;">UrbanStyle Retail</h2>
      </div>
      <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px;">
        <p>Dear ${customerName},</p>
  `;
  
  paragraphs.forEach(para => {
    const trimmed = para.trim();
    if (trimmed.startsWith('•') || trimmed.startsWith('-')) {
      // List item
      html += `<ul style="margin: 10px 0; padding-left: 20px;">`;
      trimmed.split(/\n/).forEach(item => {
        if (item.trim().match(/^[•\-]/)) {
          html += `<li style="margin: 5px 0;">${item.replace(/^[•\-]\s*/, '')}</li>`;
        }
      });
      html += `</ul>`;
    } else {
      html += `<p style="margin: 15px 0;">${trimmed}</p>`;
    }
  });
  
  html += `
        <p style="margin-top: 30px;">Best regards,<br>
        <strong>UrbanStyle Retail Team</strong><br>
        ${storeName} Store</p>
        
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 12px;">
          <p>This email was sent from UrbanStyle Retail Feedback Management System.</p>
        </div>
      </div>
    </div>
  `;
  
  return html;
}

// Fallback email generation
function generateFallbackEmail(feedback, emailType) {
  const customerName = feedback.customerName || "Valued Customer";
  const isNegative = feedback.rating <= 2;
  
  const subject = isNegative 
    ? `Follow-up on Your Feedback - ${feedback.store} Store`
    : `Thank You for Your Feedback - ${feedback.store} Store`;
  
  const body = isNegative 
    ? `Dear ${customerName},

Thank you for taking the time to share your feedback with us. We sincerely apologize for the experience you had at our ${feedback.store} store.

As the Store Manager, I want to personally follow up with you to understand more about the issue you faced. Your feedback is invaluable in helping us improve our service.

Could you please help us by sharing:
• More details about the specific issue you encountered
• What we could have done better
• Any suggestions for improvement

We take all feedback seriously and are committed to making things right. Please reply to this email or contact us directly.

We value your business and look forward to serving you better in the future.

Best regards,
UrbanStyle Retail Team
${feedback.store} Store`
    : `Dear ${customerName},

Thank you for your positive feedback! We're thrilled to hear about your great experience at our ${feedback.store} store.

As the Store Manager, I wanted to personally reach out and thank you for taking the time to share your thoughts. Your feedback helps us understand what we're doing well and motivates our team.

We'd love to hear more about your experience. If you have any additional suggestions or would like to share more details, please feel free to reply to this email.

We value your business and look forward to serving you again soon.

Best regards,
UrbanStyle Retail Team
${feedback.store} Store`;
  
  return {
    subject,
    body,
    html: convertToHTML(body, customerName, feedback.store),
  };
}

module.exports = {
  generateEmailContent,
  convertToHTML,
};

