const nodemailer = require("nodemailer");

// Email configuration - can be set via environment variables
// For prototype, we'll use a mock/console mode if not configured
const USE_REAL_EMAIL = process.env.EMAIL_HOST && process.env.EMAIL_USER && process.env.EMAIL_PASS;

let transporter = null;

if (USE_REAL_EMAIL) {
  transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT || 587,
    secure: process.env.EMAIL_SECURE === "true",
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });
}

// Generate follow-up email content
function generateFollowUpEmail(feedback, managerName, storeName) {
  const customerName = feedback.customerName || "Valued Customer";
  const isNegative = feedback.rating <= 2;
  
  const subject = isNegative 
    ? `Follow-up on Your Feedback - ${storeName} Store`
    : `Thank You for Your Feedback - ${storeName} Store`;

  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
        .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 8px 8px; }
        .button { display: inline-block; padding: 12px 24px; background: #2a5298; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h2>UrbanStyle Retail</h2>
        </div>
        <div class="content">
          <p>Dear ${customerName},</p>
          
          ${isNegative ? `
          <p>Thank you for taking the time to share your feedback with us. We sincerely apologize for the experience you had at our ${storeName} store.</p>
          
          <p>As the Store Manager, I want to personally follow up with you to understand more about the issue you faced. Your feedback is invaluable in helping us improve our service.</p>
          
          <p><strong>Could you please help us by sharing:</strong></p>
          <ul>
            <li>More details about the specific issue you encountered</li>
            <li>What we could have done better</li>
            <li>Any suggestions for improvement</li>
          </ul>
          
          <p>We take all feedback seriously and are committed to making things right. Please reply to this email or contact us directly.</p>
          ` : `
          <p>Thank you for your positive feedback! We're thrilled to hear about your great experience at our ${storeName} store.</p>
          
          <p>As the Store Manager, I wanted to personally reach out and thank you for taking the time to share your thoughts. Your feedback helps us understand what we're doing well and motivates our team.</p>
          
          <p>We'd love to hear more about your experience. If you have any additional suggestions or would like to share more details, please feel free to reply to this email.</p>
          `}
          
          <p>We value your business and look forward to serving you better in the future.</p>
          
          <p>Best regards,<br>
          <strong>${managerName}</strong><br>
          Store Manager<br>
          ${storeName} Store<br>
          UrbanStyle Retail</p>
          
          <div class="footer">
            <p>This is an automated follow-up email from UrbanStyle Retail Feedback Management System.</p>
            <p>If you have any questions, please contact our customer service team.</p>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;

  const text = `
Dear ${customerName},

${isNegative ? `
Thank you for taking the time to share your feedback with us. We sincerely apologize for the experience you had at our ${storeName} store.

As the Store Manager, I want to personally follow up with you to understand more about the issue you faced. Your feedback is invaluable in helping us improve our service.

Could you please help us by sharing:
- More details about the specific issue you encountered
- What we could have done better
- Any suggestions for improvement

We take all feedback seriously and are committed to making things right. Please reply to this email or contact us directly.
` : `
Thank you for your positive feedback! We're thrilled to hear about your great experience at our ${storeName} store.

As the Store Manager, I wanted to personally reach out and thank you for taking the time to share your thoughts. Your feedback helps us understand what we're doing well and motivates our team.

We'd love to hear more about your experience. If you have any additional suggestions or would like to share more details, please feel free to reply to this email.
`}

We value your business and look forward to serving you better in the future.

Best regards,
${managerName}
Store Manager
${storeName} Store
UrbanStyle Retail
  `;

  return { subject, html, text };
}

// Send follow-up email
async function sendFollowUpEmail(feedback, managerName, storeName, customSubject = null, customBody = null, customHtml = null) {
  if (!feedback.customerEmail) {
    throw new Error("Customer email is required to send follow-up");
  }

  const { subject, html, text } = customSubject && customBody
    ? { subject: customSubject, html: customHtml || customBody.replace(/\n/g, "<br>"), text: customBody }
    : generateFollowUpEmail(feedback, managerName, storeName);

  if (!USE_REAL_EMAIL) {
    // Mock mode - log email instead of sending
    console.log("\n=== FOLLOW-UP EMAIL (MOCK MODE) ===");
    console.log(`To: ${feedback.customerEmail}`);
    console.log(`Subject: ${subject}`);
    console.log(`\n${text}`);
    console.log("===================================\n");
    
    return {
      success: true,
      messageId: `mock-${Date.now()}`,
      mode: "mock",
    };
  }

  try {
    const info = await transporter.sendMail({
      from: `"${managerName} - UrbanStyle" <${process.env.EMAIL_USER}>`,
      to: feedback.customerEmail,
      subject: subject,
      text: text,
      html: html,
    });

    return {
      success: true,
      messageId: info.messageId,
      mode: "real",
    };
  } catch (error) {
    console.error("Email sending error:", error);
    throw new Error(`Failed to send email: ${error.message}`);
  }
}

module.exports = {
  sendFollowUpEmail,
  generateFollowUpEmail,
  USE_REAL_EMAIL,
};

