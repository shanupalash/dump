const OpenAI = require("openai");

// For prototype, we'll use a mock AI service that simulates AI analysis
// In production, you would use actual OpenAI API with an API key

function analyzeSentiment(comment) {
  const lowerComment = comment.toLowerCase();
  const negativeWords = ["poor", "bad", "terrible", "awful", "disappointed", "late", "damaged", "wrong", "broken"];
  const positiveWords = ["great", "excellent", "amazing", "love", "perfect", "good", "happy", "satisfied"];
  
  const negativeCount = negativeWords.filter(word => lowerComment.includes(word)).length;
  const positiveCount = positiveWords.filter(word => lowerComment.includes(word)).length;
  
  if (negativeCount > positiveCount) return "negative";
  if (positiveCount > negativeCount) return "positive";
  return "neutral";
}

function extractThemes(comments) {
  const themes = {
    delivery: 0,
    quality: 0,
    staff: 0,
    pricing: 0,
    packaging: 0,
    product: 0,
    service: 0,
  };
  
  const keywords = {
    delivery: ["delivery", "shipping", "arrived", "late", "fast", "slow", "dispatch"],
    quality: ["quality", "fabric", "material", "durable", "cheap", "poor quality"],
    staff: ["staff", "employee", "service", "helpful", "rude", "unhelpful"],
    pricing: ["price", "expensive", "cheap", "cost", "affordable", "overpriced"],
    packaging: ["packaging", "package", "box", "wrapped", "damaged"],
    product: ["product", "item", "size", "fit", "color", "design"],
    service: ["service", "support", "customer service", "response", "help"],
  };
  
  comments.forEach(comment => {
    const lowerComment = comment.toLowerCase();
    Object.keys(keywords).forEach(theme => {
      if (keywords[theme].some(keyword => lowerComment.includes(keyword))) {
        themes[theme]++;
      }
    });
  });
  
  return themes;
}

function generateSummary(feedback) {
  const negative = feedback.filter(f => f.rating <= 2 || analyzeSentiment(f.comment) === "negative");
  const positive = feedback.filter(f => f.rating >= 4 || analyzeSentiment(f.comment) === "positive");
  
  const themes = extractThemes(feedback.map(f => f.comment));
  const topThemes = Object.entries(themes)
    .filter(([_, count]) => count > 0)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([theme]) => theme);
  
  const storeCounts = {};
  feedback.forEach(f => {
    storeCounts[f.store] = (storeCounts[f.store] || 0) + 1;
  });
  
  const problemStores = Object.entries(storeCounts)
    .map(([store, count]) => {
      const storeFeedback = feedback.filter(f => f.store === store);
      const negativeCount = storeFeedback.filter(f => f.rating <= 2).length;
      return { store, count, negativeCount, ratio: negativeCount / count };
    })
    .filter(s => s.negativeCount > 0)
    .sort((a, b) => b.ratio - a.ratio)
    .slice(0, 3);
  
  let summary = `Total feedback: ${feedback.length}. `;
  summary += `Positive: ${positive.length} (${Math.round(positive.length / feedback.length * 100)}%), `;
  summary += `Negative: ${negative.length} (${Math.round(negative.length / feedback.length * 100)}%). `;
  
  if (topThemes.length > 0) {
    summary += `Top concerns: ${topThemes.join(", ")}. `;
  }
  
  if (problemStores.length > 0) {
    summary += `Stores needing attention: ${problemStores.map(s => s.store).join(", ")}.`;
  }
  
  return summary;
}

function generateResponse(feedback) {
  const sentiment = analyzeSentiment(feedback.comment);
  const themes = extractThemes([feedback.comment]);
  const topTheme = Object.entries(themes)
    .filter(([_, count]) => count > 0)
    .sort((a, b) => b[1] - a[1])[0];
  
  if (sentiment === "negative") {
    const responses = {
      delivery: "We sincerely apologize for the delivery delay. We're investigating this issue and will ensure faster delivery times. Please contact us for a refund or replacement.",
      quality: "Thank you for your feedback. We take quality seriously and will review this with our quality team. We'd like to offer you a replacement or full refund.",
      staff: "We apologize for the poor service experience. We'll address this with our store team immediately. Please reach out to us so we can make this right.",
      pricing: "We appreciate your feedback on pricing. We regularly review our prices to ensure value. Please contact us to discuss options.",
      packaging: "We're sorry about the packaging issue. We'll improve our packaging standards. We'd be happy to send a replacement with better packaging.",
      default: "We're sorry to hear about your experience. We take all feedback seriously and would like to make this right. Please contact our customer service team.",
    };
    
    return responses[topTheme?.[0]] || responses.default;
  }
  
  return "Thank you for your positive feedback! We're glad you had a great experience with UrbanStyle.";
}

function analyzeFeedback(feedback) {
  const negative = feedback.filter(f => f.rating <= 2 || analyzeSentiment(f.comment) === "negative");
  const themes = extractThemes(feedback.map(f => f.comment));
  const summary = generateSummary(feedback);
  
  // Store-wise analysis
  const storeAnalysis = {};
  const stores = [...new Set(feedback.map(f => f.store))];
  
  stores.forEach(store => {
    const storeFeedback = feedback.filter(f => f.store === store);
    const storeNegative = storeFeedback.filter(f => f.rating <= 2);
    const storeThemes = extractThemes(storeFeedback.map(f => f.comment));
    
    storeAnalysis[store] = {
      total: storeFeedback.length,
      negative: storeNegative.length,
      positive: storeFeedback.length - storeNegative.length,
      themes: storeThemes,
      avgRating: (storeFeedback.reduce((sum, f) => sum + f.rating, 0) / storeFeedback.length).toFixed(2),
    };
  });
  
  // Product category analysis
  const productAnalysis = {};
  const products = [...new Set(feedback.map(f => f.product))];
  
  products.forEach(product => {
    const productFeedback = feedback.filter(f => f.product === product);
    const productNegative = productFeedback.filter(f => f.rating <= 2);
    
    productAnalysis[product] = {
      total: productFeedback.length,
      negative: productNegative.length,
      avgRating: (productFeedback.reduce((sum, f) => sum + f.rating, 0) / productFeedback.length).toFixed(2),
    };
  });
  
  // Rating distribution
  const ratingDistribution = {
    1: feedback.filter(f => f.rating === 1).length,
    2: feedback.filter(f => f.rating === 2).length,
    3: feedback.filter(f => f.rating === 3).length,
    4: feedback.filter(f => f.rating === 4).length,
    5: feedback.filter(f => f.rating === 5).length,
  };
  
  return {
    total: feedback.length,
    negativeCount: negative.length,
    positiveCount: feedback.length - negative.length,
    themes,
    summary,
    storeAnalysis,
    productAnalysis,
    ratingDistribution,
  };
}

module.exports = {
  analyzeFeedback,
  analyzeSentiment,
  extractThemes,
  generateSummary,
  generateResponse,
};
