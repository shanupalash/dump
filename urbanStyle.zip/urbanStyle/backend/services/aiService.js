const OpenAI = require("openai");
const feedbackService = require("./feedbackService");

// Initialize OpenAI client
// Set OPENAI_API_KEY in environment variables or use mock mode
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "mock", // Use "mock" for development without API key
});

const USE_REAL_AI = process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY !== "mock";

// Enhanced AI-powered sentiment analysis
async function analyzeSentimentAI(comment) {
  if (!USE_REAL_AI) {
    return analyzeSentimentFallback(comment);
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a sentiment analysis expert. Analyze the sentiment of customer feedback and return only one word: 'positive', 'negative', or 'neutral'."
        },
        {
          role: "user",
          content: `Analyze the sentiment of this customer feedback: "${comment}"`
        }
      ],
      temperature: 0.3,
      max_tokens: 10
    });

    const sentiment = response.choices[0].message.content.trim().toLowerCase();
    return sentiment.includes("positive") ? "positive" : 
           sentiment.includes("negative") ? "negative" : "neutral";
  } catch (error) {
    console.error("AI sentiment analysis error:", error);
    return analyzeSentimentFallback(comment);
  }
}

// Fallback sentiment analysis
function analyzeSentimentFallback(comment) {
  const lowerComment = comment.toLowerCase();
  const negativeWords = ["poor", "bad", "terrible", "awful", "disappointed", "late", "damaged", "wrong", "broken", "horrible", "worst", "hate", "disgusting"];
  const positiveWords = ["great", "excellent", "amazing", "love", "perfect", "good", "happy", "satisfied", "wonderful", "fantastic", "best", "awesome"];
  
  const negativeCount = negativeWords.filter(word => lowerComment.includes(word)).length;
  const positiveCount = positiveWords.filter(word => lowerComment.includes(word)).length;
  
  if (negativeCount > positiveCount) return "negative";
  if (positiveCount > negativeCount) return "positive";
  return "neutral";
}

// AI-powered theme extraction
async function extractThemesAI(comments) {
  if (!USE_REAL_AI) {
    return extractThemesFallback(comments);
  }

  try {
    const commentsText = comments.slice(0, 50).join(" | "); // Limit to avoid token limits
    
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a data analyst. Extract key themes from customer feedback. Return a JSON object with theme names as keys and counts as values. Themes should include: delivery, quality, staff, pricing, packaging, product, service."
        },
        {
          role: "user",
          content: `Extract themes from these customer comments: ${commentsText}`
        }
      ],
      temperature: 0.3,
      response_format: { type: "json_object" }
    });

    const themes = JSON.parse(response.choices[0].message.content);
    return themes;
  } catch (error) {
    console.error("AI theme extraction error:", error);
    return extractThemesFallback(comments);
  }
}

// Fallback theme extraction
function extractThemesFallback(comments) {
  const themes = {
    delivery: 0,
    quality: 0,
    staff: 0,
    pricing: 0,
    packaging: 0,
    product: 0,
    service: 0,
  };
  
  const keywords = {
    delivery: ["delivery", "shipping", "arrived", "late", "fast", "slow", "dispatch", "shipment"],
    quality: ["quality", "fabric", "material", "durable", "cheap", "poor quality", "flimsy", "sturdy"],
    staff: ["staff", "employee", "service", "helpful", "rude", "unhelpful", "friendly", "professional"],
    pricing: ["price", "expensive", "cheap", "cost", "affordable", "overpriced", "value", "worth"],
    packaging: ["packaging", "package", "box", "wrapped", "damaged", "secure", "presentation"],
    product: ["product", "item", "size", "fit", "color", "design", "style", "fabric"],
    service: ["service", "support", "customer service", "response", "help", "assistance"],
  };
  
  comments.forEach(comment => {
    const lowerComment = comment.toLowerCase();
    Object.keys(keywords).forEach(theme => {
      if (keywords[theme].some(keyword => lowerComment.includes(keyword))) {
        themes[theme]++;
      }
    });
  });
  
  return themes;
}

// AI-powered summary generation
async function generateSummaryAI(feedback) {
  if (!USE_REAL_AI) {
    return generateSummaryFallback(feedback);
  }

  try {
    const feedbackSummary = feedback.slice(0, 100).map(f => 
      `Store: ${f.store}, Rating: ${f.rating}/5, Comment: ${f.comment}`
    ).join("\n");

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a business analyst. Generate a concise executive summary of customer feedback data. Highlight key insights, trends, and areas needing attention."
        },
        {
          role: "user",
          content: `Generate an executive summary for this feedback data:\n\n${feedbackSummary}\n\nTotal feedback: ${feedback.length}`
        }
      ],
      temperature: 0.7,
      max_tokens: 300
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error("AI summary generation error:", error);
    return generateSummaryFallback(feedback);
  }
}

function generateSummaryFallback(feedback) {
  const negative = feedback.filter(f => f.rating <= 2);
  const positive = feedback.filter(f => f.rating >= 4);
  
  const themes = extractThemesFallback(feedback.map(f => f.comment));
  const topThemes = Object.entries(themes)
    .filter(([_, count]) => count > 0)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([theme]) => theme);
  
  const storeCounts = {};
  feedback.forEach(f => {
    storeCounts[f.store] = (storeCounts[f.store] || 0) + 1;
  });
  
  const problemStores = Object.entries(storeCounts)
    .map(([store, count]) => {
      const storeFeedback = feedback.filter(f => f.store === store);
      const negativeCount = storeFeedback.filter(f => f.rating <= 2).length;
      return { store, count, negativeCount, ratio: negativeCount / count };
    })
    .filter(s => s.negativeCount > 0)
    .sort((a, b) => b.ratio - a.ratio)
    .slice(0, 3);
  
  let summary = `Total feedback: ${feedback.length}. `;
  summary += `Positive: ${positive.length} (${Math.round(positive.length / feedback.length * 100)}%), `;
  summary += `Negative: ${negative.length} (${Math.round(negative.length / feedback.length * 100)}%). `;
  
  if (topThemes.length > 0) {
    summary += `Top concerns: ${topThemes.join(", ")}. `;
  }
  
  if (problemStores.length > 0) {
    summary += `Stores needing attention: ${problemStores.map(s => s.store).join(", ")}.`;
  }
  
  return summary;
}

// AI-powered response generation
async function generateResponseAI(feedback) {
  if (!USE_REAL_AI) {
    return generateResponseFallback(feedback);
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a customer service expert for UrbanStyle Retail. Generate professional, empathetic, and actionable responses to customer feedback. Be specific and offer solutions."
        },
        {
          role: "user",
          content: `Generate a customer service response for this feedback:\nStore: ${feedback.store}\nProduct: ${feedback.product}\nRating: ${feedback.rating}/5\nComment: ${feedback.comment}`
        }
      ],
      temperature: 0.7,
      max_tokens: 200
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error("AI response generation error:", error);
    return generateResponseFallback(feedback);
  }
}

function generateResponseFallback(feedback) {
  const sentiment = analyzeSentimentFallback(feedback.comment);
  const themes = extractThemesFallback([feedback.comment]);
  const topTheme = Object.entries(themes)
    .filter(([_, count]) => count > 0)
    .sort((a, b) => b[1] - a[1])[0];
  
  if (sentiment === "negative") {
    const responses = {
      delivery: "We sincerely apologize for the delivery delay. We're investigating this issue and will ensure faster delivery times. Please contact us for a refund or replacement.",
      quality: "Thank you for your feedback. We take quality seriously and will review this with our quality team. We'd like to offer you a replacement or full refund.",
      staff: "We apologize for the poor service experience. We'll address this with our store team immediately. Please reach out to us so we can make this right.",
      pricing: "We appreciate your feedback on pricing. We regularly review our prices to ensure value. Please contact us to discuss options.",
      packaging: "We're sorry about the packaging issue. We'll improve our packaging standards. We'd be happy to send a replacement with better packaging.",
      default: "We're sorry to hear about your experience. We take all feedback seriously and would like to make this right. Please contact our customer service team.",
    };
    
    return responses[topTheme?.[0]] || responses.default;
  }
  
  return "Thank you for your positive feedback! We're glad you had a great experience with UrbanStyle.";
}

// AI Chatbot for Q&A
async function chatWithAI(question, context = {}) {
  if (!USE_REAL_AI) {
    return chatWithAIFallback(question, context);
  }

  try {
    // Get relevant feedback context
    let allFeedback = feedbackService.readFeedback();
    
    // Filter by store if manager
    if (context.store) {
      allFeedback = allFeedback.filter(f => f.store === context.store);
    }
    
    // Calculate statistics for context
    const total = allFeedback.length;
    const positive = allFeedback.filter(f => f.rating >= 4).length;
    const negative = allFeedback.filter(f => f.rating <= 2).length;
    const satisfaction = total > 0 ? Math.round((positive / total) * 100) : 0;
    
    // Store analysis
    const storeAnalysis = {};
    const stores = [...new Set(allFeedback.map(f => f.store))];
    stores.forEach(store => {
      const storeFeedback = allFeedback.filter(f => f.store === store);
      const storeNegative = storeFeedback.filter(f => f.rating <= 2).length;
      const storeTotal = storeFeedback.length;
      const storeAvgRating = storeFeedback.reduce((sum, f) => sum + f.rating, 0) / storeTotal;
      storeAnalysis[store] = {
        total: storeTotal,
        negative: storeNegative,
        avgRating: storeAvgRating.toFixed(2),
        negativeRatio: storeTotal > 0 ? ((storeNegative / storeTotal) * 100).toFixed(1) : 0
      };
    });
    
    // Top issues
    const negativeFeedback = allFeedback.filter(f => f.rating <= 2);
    const topIssues = extractThemesFallback(negativeFeedback.map(f => f.comment));
    const topIssuesList = Object.entries(topIssues)
      .filter(([_, count]) => count > 0)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([issue, count]) => `${issue}: ${count} complaints`)
      .join(", ");
    
    const recentFeedback = allFeedback.slice(-20).map(f => 
      `Store: ${f.store}, Rating: ${f.rating}/5, Comment: ${f.comment.substring(0, 100)}`
    ).join("\n");

    const systemPrompt = `You are an AI assistant for UrbanStyle Retail's feedback management system. 
You help answer questions about customer feedback, identify issues, and suggest resolutions.

**Your Response Style:**
- Use clear, structured formatting with sections and bullet points
- Include emojis for visual clarity (📊 for data, 🔍 for analysis, 💡 for suggestions)
- Organize information in logical sections with headers
- Provide specific, actionable recommendations
- Use data-driven insights from the feedback statistics
- Keep responses professional yet friendly
- Format with proper spacing and line breaks for readability

**Response Structure:**
1. Clear title/header with emoji
2. Key statistics or summary
3. Detailed breakdown in organized sections
4. Actionable recommendations
5. Closing with offer for more help

Always provide well-formatted, easy-to-read responses with proper structure.`;

    const userPrompt = `**Feedback Statistics:**
- Total feedback: ${total}
- Satisfaction rate: ${satisfaction}%
- Positive: ${positive}, Negative: ${negative}
- Top issues: ${topIssuesList || "None"}

**Store Performance:**
${Object.entries(storeAnalysis).map(([store, data]) => 
  `${store}: ${data.total} feedback, ${data.negative} negative (${data.negativeRatio}%), Avg rating: ${data.avgRating}/5`
).join("\n")}

**Recent Feedback Sample:**
${recentFeedback || "No recent feedback"}

**User Question:** ${question}

Please provide a detailed, data-driven response with specific recommendations.`;

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      temperature: 0.7,
      max_tokens: 500
    });

    return response.choices[0].message.content;
  } catch (error) {
    console.error("AI chat error:", error);
    return chatWithAIFallback(question, context);
  }
}

function chatWithAIFallback(question, context) {
  const lowerQuestion = question.toLowerCase();
  const allFeedback = feedbackService.readFeedback();
  
  // Filter by store if manager
  let feedback = allFeedback;
  if (context.store) {
    feedback = feedback.filter(f => f.store === context.store);
  }
  
  // Store needs attention
  if (lowerQuestion.includes("store") && (lowerQuestion.includes("attention") || lowerQuestion.includes("need") || lowerQuestion.includes("problem") || lowerQuestion.includes("issue"))) {
    const storeAnalysis = {};
    const stores = [...new Set(feedback.map(f => f.store))];
    
    stores.forEach(store => {
      const storeFeedback = feedback.filter(f => f.store === store);
      const negative = storeFeedback.filter(f => f.rating <= 2).length;
      const total = storeFeedback.length;
      const avgRating = storeFeedback.reduce((sum, f) => sum + f.rating, 0) / total;
      const negativeRatio = total > 0 ? (negative / total) * 100 : 0;
      
      storeAnalysis[store] = {
        total,
        negative,
        avgRating: avgRating.toFixed(2),
        negativeRatio: negativeRatio.toFixed(1)
      };
    });
    
    const problemStores = Object.entries(storeAnalysis)
      .filter(([_, data]) => data.negative > 0)
      .sort((a, b) => b[1].negativeRatio - a[1].negativeRatio)
      .slice(0, 5);
    
    if (problemStores.length === 0) {
      return "✅ **All Stores Performing Well**\n\nGreat news! All stores are performing well with no significant issues reported. Keep up the excellent work!";
    }
    
    let response = "📊 **Stores Requiring Attention**\n\n";
    response += "Based on customer feedback analysis, here are the stores that need immediate attention:\n\n";
    
    problemStores.forEach(([store, data], index) => {
      response += `**${index + 1}. ${store}**\n`;
      response += `   • Negative Feedback: ${data.negative} (${data.negativeRatio}%)\n`;
      response += `   • Average Rating: ${data.avgRating}/5\n`;
      response += `   • Total Feedback: ${data.total}\n\n`;
    });
    
    response += `---\n\n`;
    response += `**📋 Recommended Actions:**\n\n`;
    response += `1. **Immediate Review**: Analyze feedback from these stores to identify common issues\n`;
    response += `2. **Store Audits**: Conduct comprehensive audits focusing on customer service and quality\n`;
    response += `3. **Staff Training**: Implement targeted training programs for store teams\n`;
    response += `4. **Customer Follow-up**: Reach out to customers who provided negative feedback\n`;
    response += `5. **Progress Monitoring**: Track improvements over the next 30 days\n\n`;
    response += `💡 *Would you like detailed analysis for any specific store?*`;
    
    return response;
  }
  
  // How to improve customer satisfaction/attention
  if (lowerQuestion.includes("improve") || lowerQuestion.includes("better") || lowerQuestion.includes("enhance") || lowerQuestion.includes("customer satisfaction") || lowerQuestion.includes("customer attention")) {
    const positive = feedback.filter(f => f.rating >= 4).length;
    const negative = feedback.filter(f => f.rating <= 2).length;
    const neutral = feedback.filter(f => f.rating === 3).length;
    const total = feedback.length;
    const satisfaction = total > 0 ? Math.round((positive / total) * 100) : 0;
    
    const negativeFeedback = feedback.filter(f => f.rating <= 2);
    const topIssues = extractThemesFallback(negativeFeedback.map(f => f.comment));
    const topIssuesList = Object.entries(topIssues)
      .filter(([_, count]) => count > 0)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3);
    
    let response = `📈 **Customer Satisfaction Improvement Plan**\n\n`;
    response += `**Current Status:**\n`;
    response += `• Satisfaction Rate: ${satisfaction}%\n`;
    response += `• Positive Feedback: ${positive} (${total > 0 ? Math.round(positive/total*100) : 0}%)\n`;
    response += `• Negative Feedback: ${negative} (${total > 0 ? Math.round(negative/total*100) : 0}%)\n`;
    response += `• Neutral Feedback: ${neutral} (${total > 0 ? Math.round(neutral/total*100) : 0}%)\n\n`;
    
    if (topIssuesList.length > 0) {
      response += `**🔍 Top Issues to Address:**\n\n`;
      topIssuesList.forEach(([issue, count], index) => {
        response += `${index + 1}. **${issue.charAt(0).toUpperCase() + issue.slice(1)}** - ${count} complaint${count > 1 ? 's' : ''}\n`;
      });
      response += `\n`;
    }
    
    response += `---\n\n`;
    response += `**📋 Strategic Action Plan:**\n\n`;
    response += `**1. Immediate Actions (Week 1-2)**\n`;
    response += `   • Respond to all negative feedback within 24 hours\n`;
    response += `   • Offer immediate solutions (refunds, replacements, discounts)\n`;
    response += `   • Conduct emergency training on ${topIssuesList[0]?.[0] || "customer service"}\n\n`;
    
    response += `**2. Short-term Improvements (Month 1)**\n`;
    response += `   • Implement stricter quality control processes\n`;
    response += `   • Create automated follow-up system for negative feedback\n`;
    response += `   • Set up weekly feedback review meetings\n`;
    response += `   • Launch customer service excellence program\n\n`;
    
    response += `**3. Long-term Enhancements (Month 2-3)**\n`;
    response += `   • Develop comprehensive staff training curriculum\n`;
    response += `   • Implement customer feedback loop system\n`;
    response += `   • Establish reward program for positive feedback\n`;
    response += `   • Create proactive customer outreach program\n\n`;
    
    response += `**⚡ Quick Wins:**\n`;
    response += `• Share positive feedback with teams daily\n`;
    response += `• Implement "Customer First" policy\n`;
    response += `• Create feedback response templates\n`;
    response += `• Set up real-time feedback monitoring\n\n`;
    
    response += `💡 *Target: Increase satisfaction rate to ${satisfaction + 10}% within 90 days*\n\n`;
    response += `Would you like specific recommendations for any particular area?`;
    
    return response;
  }
  
  // Simple pattern matching for common questions
  if (lowerQuestion.includes("issue") || lowerQuestion.includes("problem") || lowerQuestion.includes("complaint")) {
    const negativeFeedback = feedback.filter(f => f.rating <= 2);
    const topIssues = extractThemesFallback(negativeFeedback.map(f => f.comment));
    const topIssuesList = Object.entries(topIssues)
      .filter(([_, count]) => count > 0)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
    
    if (topIssuesList.length === 0) {
      return "✅ **No Significant Issues**\n\nGreat news! There are no significant issues reported in the feedback. All systems are running smoothly!";
    }
    
    let response = `🔍 **Customer Issues Analysis**\n\n`;
    response += `Based on customer feedback analysis, here are the main issues:\n\n`;
    
    topIssuesList.forEach(([issue, count], index) => {
      response += `**${index + 1}. ${issue.charAt(0).toUpperCase() + issue.slice(1)}**\n`;
      response += `   • Complaints: ${count}\n`;
      response += `   • Priority: ${index === 0 ? 'High' : index === 1 ? 'Medium' : 'Low'}\n\n`;
    });
    
    const topIssue = topIssuesList[0];
    response += `---\n\n`;
    response += `**📋 Recommended Actions for ${topIssue[0].charAt(0).toUpperCase() + topIssue[0].slice(1)}:**\n\n`;
    response += `1. **Process Review**: Analyze ${topIssue[0]} processes and identify bottlenecks\n`;
    response += `2. **Staff Training**: Conduct training on ${topIssue[0]} handling and best practices\n`;
    response += `3. **Quality Checks**: Implement quality control measures for ${topIssue[0]}\n`;
    response += `4. **Monitoring**: Set up alerts and monitoring for ${topIssue[0]}-related issues\n`;
    response += `5. **Feedback Loop**: Create system to track improvements in ${topIssue[0]}\n\n`;
    response += `💡 *Would you like more specific recommendations for any of these issues?*`;
    
    return response;
  }
  
  if (lowerQuestion.includes("resolve") || lowerQuestion.includes("fix") || lowerQuestion.includes("solution")) {
    return `🛠️ **Issue Resolution Framework**\n\n**Step-by-Step Process:**\n\n**1. Root Cause Analysis**\n   • Analyze feedback patterns and trends\n   • Identify underlying issues, not just symptoms\n   • Categorize issues by type and severity\n\n**2. Prioritization**\n   • Focus on high-impact issues affecting multiple customers\n   • Address critical issues first (safety, quality, service)\n   • Create priority matrix based on frequency and impact\n\n**3. Solution Implementation**\n   • Develop targeted solutions (training, process improvements, quality checks)\n   • Assign ownership and set deadlines\n   • Allocate necessary resources\n\n**4. Customer Follow-up**\n   • Contact affected customers within 24 hours\n   • Offer immediate solutions (refund, replacement, discount)\n   • Ensure customer satisfaction with resolution\n\n**5. Monitoring & Improvement**\n   • Track feedback trends to measure improvement\n   • Document all resolutions for future reference\n   • Learn from patterns to prevent recurrence\n\n---\n\n**✅ Best Practices:**\n• Response time: < 24 hours for all complaints\n• Solution-oriented approach: Always offer alternatives\n• Documentation: Maintain detailed resolution records\n• Continuous learning: Update processes based on feedback\n\n💡 *Would you like me to analyze specific feedback to provide targeted solutions?*`;
  }
  
  if (lowerQuestion.includes("sentiment") || lowerQuestion.includes("satisfaction")) {
    const positive = feedback.filter(f => f.rating >= 4).length;
    const negative = feedback.filter(f => f.rating <= 2).length;
    const neutral = feedback.filter(f => f.rating === 3).length;
    const total = feedback.length;
    const satisfaction = total > 0 ? Math.round((positive / total) * 100) : 0;
    
    return `📊 **Customer Satisfaction Analysis**\n\n**Overall Satisfaction Rate: ${satisfaction}%**\n\n**Feedback Breakdown:**\n\n` +
      `✅ **Positive** (4-5 stars)\n` +
      `   • Count: ${positive}\n` +
      `   • Percentage: ${total > 0 ? Math.round(positive/total*100) : 0}%\n\n` +
      `⚠️ **Neutral** (3 stars)\n` +
      `   • Count: ${neutral}\n` +
      `   • Percentage: ${total > 0 ? Math.round(neutral/total*100) : 0}%\n\n` +
      `❌ **Negative** (1-2 stars)\n` +
      `   • Count: ${negative}\n` +
      `   • Percentage: ${total > 0 ? Math.round(negative/total*100) : 0}%\n\n` +
      `---\n\n` +
      `**Total Feedback Collected:** ${total}\n\n` +
      `**📈 I can help you explore:**\n` +
      `• Store-specific performance analysis\n` +
      `• Product feedback trends\n` +
      `• Time-based sentiment changes\n` +
      `• Issue categorization and patterns\n\n` +
      `💡 *What would you like to explore in more detail?*`;
  }
  
  return `👋 **Welcome to UrbanStyle AI Assistant**\n\nI'm here to help you analyze customer feedback and improve customer satisfaction.\n\n**📊 What I Can Help With:**\n\n**Analytics & Insights**\n• Customer satisfaction rates and trends\n• Store performance comparisons\n• Product feedback analysis\n• Sentiment analysis reports\n\n**🔍 Issue Identification**\n• Which stores need attention\n• Common customer complaints\n• Problem areas and themes\n• Root cause analysis\n\n**💡 Improvement Strategies**\n• How to improve customer satisfaction\n• Resolution recommendations\n• Best practices and action plans\n• Quick wins and long-term solutions\n\n**📈 Reports & Trends**\n• Feedback patterns over time\n• Store-wise performance breakdowns\n• Product category analysis\n• Predictive insights\n\n---\n\n**💬 Try asking:**\n• "Which stores need attention?"\n• "How to improve customer satisfaction?"\n• "What are the main customer issues?"\n• "Show me satisfaction rates"\n\n*What would you like to know?*`;
}

// AI-powered issue resolution suggestions
async function suggestResolutions(feedbackId) {
  const feedback = feedbackService.getFeedbackById(feedbackId);
  if (!feedback) return null;

  if (!USE_REAL_AI) {
    return suggestResolutionsFallback(feedback);
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a customer service expert. Provide 3-5 specific, actionable resolution steps for customer issues."
        },
        {
          role: "user",
          content: `Customer feedback:\nStore: ${feedback.store}\nProduct: ${feedback.product}\nRating: ${feedback.rating}/5\nComment: ${feedback.comment}\n\nProvide resolution steps.`
        }
      ],
      temperature: 0.7,
      max_tokens: 300
    });

    const resolutions = response.choices[0].message.content.split(/\d+\./).filter(r => r.trim()).map(r => r.trim());
    return resolutions;
  } catch (error) {
    console.error("AI resolution suggestion error:", error);
    return suggestResolutionsFallback(feedback);
  }
}

function suggestResolutionsFallback(feedback) {
  const sentiment = analyzeSentimentFallback(feedback.comment);
  const themes = extractThemesFallback([feedback.comment]);
  const topTheme = Object.entries(themes).sort((a, b) => b[1] - a[1])[0]?.[0];

  if (sentiment === "negative") {
    const resolutions = {
      delivery: [
        "Contact customer to apologize and offer expedited shipping",
        "Review delivery partner performance and set SLAs",
        "Implement delivery tracking notifications",
        "Offer compensation (discount or refund)"
      ],
      quality: [
        "Request photos of quality issue for investigation",
        "Offer immediate replacement or full refund",
        "Review quality control processes",
        "Escalate to quality assurance team"
      ],
      staff: [
        "Review incident with store manager",
        "Provide additional customer service training",
        "Implement customer service standards",
        "Follow up with customer to ensure satisfaction"
      ],
      default: [
        "Acknowledge the issue and apologize",
        "Investigate the root cause",
        "Offer appropriate compensation",
        "Follow up to ensure resolution"
      ]
    };

    return resolutions[topTheme] || resolutions.default;
  }

  return ["Thank customer for positive feedback", "Share positive feedback with team", "Consider featuring in testimonials"];
}

// AI-powered auto-categorization
async function autoCategorizeFeedback(feedback) {
  if (!USE_REAL_AI) {
    return autoCategorizeFallback(feedback);
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "Categorize customer feedback into one of: delivery, quality, staff, pricing, packaging, product, service, other. Return only the category name."
        },
        {
          role: "user",
          content: `Categorize: "${feedback.comment}"`
        }
      ],
      temperature: 0.3,
      max_tokens: 20
    });

    return response.choices[0].message.content.trim().toLowerCase();
  } catch (error) {
    console.error("AI categorization error:", error);
    return autoCategorizeFallback(feedback);
  }
}

function autoCategorizeFallback(feedback) {
  const themes = extractThemesFallback([feedback.comment]);
  const topTheme = Object.entries(themes).sort((a, b) => b[1] - a[1])[0];
  return topTheme ? topTheme[0] : "other";
}

// Main analyze function with AI
async function analyzeFeedback(feedback) {
  const negative = feedback.filter(f => f.rating <= 2);
  const themes = await extractThemesAI(feedback.map(f => f.comment));
  const summary = await generateSummaryAI(feedback);
  
  // Store-wise analysis
  const storeAnalysis = {};
  const stores = [...new Set(feedback.map(f => f.store))];
  
  stores.forEach(store => {
    const storeFeedback = feedback.filter(f => f.store === store);
    const storeNegative = storeFeedback.filter(f => f.rating <= 2);
    const storeThemes = extractThemesFallback(storeFeedback.map(f => f.comment));
    
    storeAnalysis[store] = {
      total: storeFeedback.length,
      negative: storeNegative.length,
      positive: storeFeedback.length - storeNegative.length,
      themes: storeThemes,
      avgRating: (storeFeedback.reduce((sum, f) => sum + f.rating, 0) / storeFeedback.length).toFixed(2),
    };
  });
  
  // Product category analysis
  const productAnalysis = {};
  const products = [...new Set(feedback.map(f => f.product))];
  
  products.forEach(product => {
    const productFeedback = feedback.filter(f => f.product === product);
    const productNegative = productFeedback.filter(f => f.rating <= 2);
    
    productAnalysis[product] = {
      total: productFeedback.length,
      negative: productNegative.length,
      avgRating: (productFeedback.reduce((sum, f) => sum + f.rating, 0) / productFeedback.length).toFixed(2),
    };
  });
  
  // Rating distribution
  const ratingDistribution = {
    1: feedback.filter(f => f.rating === 1).length,
    2: feedback.filter(f => f.rating === 2).length,
    3: feedback.filter(f => f.rating === 3).length,
    4: feedback.filter(f => f.rating === 4).length,
    5: feedback.filter(f => f.rating === 5).length,
  };
  
  return {
    total: feedback.length,
    negativeCount: negative.length,
    positiveCount: feedback.length - negative.length,
    themes,
    summary,
    storeAnalysis,
    productAnalysis,
    ratingDistribution,
  };
}

module.exports = {
  analyzeFeedback,
  analyzeSentiment: analyzeSentimentAI,
  extractThemes: extractThemesAI,
  generateSummary: generateSummaryAI,
  generateResponse: generateResponseAI,
  chatWithAI,
  suggestResolutions,
  autoCategorizeFeedback,
  USE_REAL_AI,
};
