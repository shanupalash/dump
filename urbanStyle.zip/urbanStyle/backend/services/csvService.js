const fs = require("fs");
const csv = require("csv-parser");

function parseCSV(filePath) {
  return new Promise((resolve, reject) => {
    const results = [];

    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (data) => {
        results.push({
          id: `FB${Date.now()}${Math.floor(Math.random() * 1000)}`,
          store: data.store,
          channel: data.channel || "Microsoft Form",
          product: data.product,
          rating: Number(data.rating),
          comment: data.comment,
          createdAt: new Date().toISOString().split("T")[0],
        });
      })
      .on("end", () => resolve(results))
      .on("error", (err) => reject(err));
  });
}

module.exports = parseCSV;
