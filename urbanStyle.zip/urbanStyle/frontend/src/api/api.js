import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000",
});

// Add request interceptor to include auth headers
api.interceptors.request.use(
  (config) => {
    const user = JSON.parse(localStorage.getItem("user") || "null");
    if (user) {
      config.headers["x-role"] = user.role;
      config.headers["x-store"] = user.store || "";
      config.headers["x-username"] = user.username || "";
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem("user");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

export default api;
