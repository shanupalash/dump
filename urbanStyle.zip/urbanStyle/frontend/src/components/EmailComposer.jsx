import { useState, useEffect } from "react";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";

export default function EmailComposer({ feedback, onSend, onClose }) {
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [html, setHtml] = useState("");
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [previewMode, setPreviewMode] = useState("edit"); // edit or preview
  const [customInstructions, setCustomInstructions] = useState("");
  const { user } = useAuth();

  useEffect(() => {
    if (feedback) {
      generateEmail();
    }
  }, [feedback]);

  const generateEmail = async () => {
    setGenerating(true);
    try {
      const res = await api.post("/ai/generate-email", {
        feedbackId: feedback.id,
        emailType: "followup",
        customInstructions: customInstructions,
      });

      if (res.data.success && res.data.emailContent) {
        setSubject(res.data.emailContent.subject || "");
        setBody(res.data.emailContent.body || "");
        setHtml(res.data.emailContent.html || res.data.emailContent.body?.replace(/\n/g, "<br>") || "");
      }
    } catch (error) {
      console.error("Error generating email:", error);
      alert("Error generating email. Using default template.");
    } finally {
      setGenerating(false);
    }
  };

  const handleRegenerate = () => {
    generateEmail();
  };

  const handleSend = async () => {
    if (!subject.trim() || !body.trim()) {
      alert("Please fill in both subject and body");
      return;
    }

    setLoading(true);
    try {
      await api.post("/followup/send", {
        feedbackId: feedback.id,
        subject: subject,
        body: body,
        html: html,
        customMessage: customInstructions,
      });

      if (onSend) {
        onSend();
      }
      if (onClose) {
        onClose();
      }
    } catch (error) {
      alert(error.response?.data?.message || "Error sending email");
    } finally {
      setLoading(false);
    }
  };

  if (!feedback) return null;

  return (
    <div className="email-composer">
      <div className="email-composer-header">
        <h3>Compose Follow-up Email</h3>
        <div style={{ display: "flex", gap: "0.5rem" }}>
          <button
            className="btn btn-secondary"
            onClick={() => setPreviewMode(previewMode === "edit" ? "preview" : "edit")}
            style={{ padding: "0.5rem 1rem", fontSize: "0.875rem" }}
          >
            {previewMode === "edit" ? "Preview" : "Edit"}
          </button>
          <button onClick={onClose} className="chat-close-btn" style={{ background: "transparent", border: "none", fontSize: "1.5rem" }}>×</button>
        </div>
      </div>

      <div className="email-composer-body">
        <div className="email-composer-info">
          <div>
            <strong>To:</strong> {feedback.customerEmail}
          </div>
          <div>
            <strong>Customer:</strong> {feedback.customerName || "N/A"}
          </div>
          <div>
            <strong>Store:</strong> {feedback.store}
          </div>
        </div>

        {previewMode === "edit" ? (
          <>
            <div className="form-group">
              <label className="form-label">
                Subject
                <button
                  onClick={handleRegenerate}
                  disabled={generating}
                  className="btn btn-secondary"
                  style={{ 
                    marginLeft: "1rem", 
                    padding: "0.25rem 0.75rem", 
                    fontSize: "0.75rem" 
                  }}
                >
                  {generating ? "Generating..." : "🤖 Regenerate with AI"}
                </button>
              </label>
              <input
                type="text"
                className="form-input"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Email subject..."
              />
            </div>

            <div className="form-group">
              <label className="form-label">Email Body</label>
              <textarea
                className="form-textarea"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Email body content..."
                rows={12}
                style={{ fontFamily: "monospace", fontSize: "0.9rem" }}
              />
            </div>

            <div className="form-group">
              <label className="form-label">
                AI Instructions (Optional)
                <span style={{ fontSize: "0.75rem", color: "#666", marginLeft: "0.5rem" }}>
                  Add specific instructions for AI email generation
                </span>
              </label>
              <textarea
                className="form-textarea"
                value={customInstructions}
                onChange={(e) => setCustomInstructions(e.target.value)}
                placeholder="E.g., 'Make it more empathetic' or 'Focus on quality issues'"
                rows={2}
              />
            </div>
          </>
        ) : (
          <div className="email-preview">
            <div className="email-preview-header">
              <strong>Subject:</strong> {subject}
            </div>
            <div 
              className="email-preview-body"
              dangerouslySetInnerHTML={{ __html: html || body.replace(/\n/g, "<br>") }}
            />
          </div>
        )}
      </div>

      <div className="email-composer-footer">
        <button
          className="btn btn-secondary"
          onClick={onClose}
          disabled={loading}
        >
          Cancel
        </button>
        <button
          className="btn btn-primary"
          onClick={handleSend}
          disabled={loading || !subject.trim() || !body.trim()}
        >
          {loading ? "Sending..." : "Send Email"}
        </button>
      </div>
    </div>
  );
}

