import { Bar, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

export default function Charts({ summary }) {
  if (!summary || !summary.themes) {
    return null;
  }

  const themeData = {
    labels: Object.keys(summary.themes).filter(key => summary.themes[key] > 0),
    datasets: [
      {
        label: "Theme Frequency",
        data: Object.keys(summary.themes)
          .filter(key => summary.themes[key] > 0)
          .map(key => summary.themes[key]),
        backgroundColor: [
          "#1e3c72",
          "#2a5298",
          "#667eea",
          "#764ba2",
          "#4facfe",
          "#43e97b",
          "#fa709a",
        ],
        borderColor: [
          "#2a5298",
          "#3d6bb3",
          "#764ba2",
          "#8b5fbf",
          "#00f2fe",
          "#38f9d7",
          "#fee140",
        ],
        borderWidth: 2,
        borderRadius: 8,
      },
    ],
  };

  const ratingData = summary.ratingDistribution ? {
    labels: ["1 Star", "2 Stars", "3 Stars", "4 Stars", "5 Stars"],
    datasets: [
      {
        label: "Rating Distribution",
        data: [
          summary.ratingDistribution[1] || 0,
          summary.ratingDistribution[2] || 0,
          summary.ratingDistribution[3] || 0,
          summary.ratingDistribution[4] || 0,
          summary.ratingDistribution[5] || 0,
        ],
        backgroundColor: [
          "#dc3545",
          "#fd7e14",
          "#ffc107",
          "#20c997",
          "#28a745",
        ],
      },
    ],
  } : null;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: "1.5rem" }}>
      <div className="chart-container">
        <h3 className="card-title">Key Themes in Feedback</h3>
        <Bar
          data={themeData}
          options={{
            responsive: true,
            plugins: {
              legend: { display: false },
              title: { display: false },
            },
          }}
        />
      </div>

      {ratingData && (
        <div className="chart-container">
          <h3 className="card-title">Rating Distribution</h3>
          <Doughnut
            data={ratingData}
            options={{
              responsive: true,
              plugins: {
                legend: { position: "bottom" },
              },
            }}
          />
        </div>
      )}
    </div>
  );
}
