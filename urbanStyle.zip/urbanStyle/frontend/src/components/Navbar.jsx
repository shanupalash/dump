import { useContext } from "react";
import { Link, useLocation } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useContext(AuthContext);
  const location = useLocation();

  if (!user) return null;

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="navbar">
      <div className="navbar-content">
        <Link to="/dashboard" className="navbar-brand">
          UrbanStyle Feedback Portal
        </Link>
        <div className="navbar-links">
          <Link
            to="/dashboard"
            className={`navbar-link ${isActive("/dashboard") ? "active" : ""}`}
          >
            Dashboard
          </Link>
          <Link
            to="/feedback"
            className={`navbar-link ${isActive("/feedback") ? "active" : ""}`}
          >
            Feedback
          </Link>
          <Link
            to="/reports"
            className={`navbar-link ${isActive("/reports") ? "active" : ""}`}
          >
            Reports
          </Link>
          <Link
            to="/followups"
            className={`navbar-link ${isActive("/followups") ? "active" : ""}`}
          >
            Follow-ups
          </Link>
          <Link
            to="/ai-assistant"
            className={`navbar-link ${isActive("/ai-assistant") ? "active" : ""}`}
            style={{ 
              background: "rgba(255, 255, 255, 0.2)",
              fontWeight: "600"
            }}
          >
            🤖 AI Assistant
          </Link>
          {user.role === "ADMIN" && (
            <Link
              to="/upload"
              className={`navbar-link ${isActive("/upload") ? "active" : ""}`}
            >
              Upload
            </Link>
          )}
          <div style={{ 
            display: "flex", 
            alignItems: "center", 
            gap: "0.75rem",
            padding: "0.5rem 1rem",
            background: "rgba(255, 255, 255, 0.1)",
            borderRadius: "8px",
            border: "1px solid rgba(255, 255, 255, 0.2)"
          }}>
            <div style={{ 
              width: "8px", 
              height: "8px", 
              borderRadius: "50%", 
              background: "#4ade80",
              boxShadow: "0 0 8px rgba(74, 222, 128, 0.6)"
            }}></div>
            <span style={{ color: "rgba(255,255,255,0.95)", fontSize: "0.875rem", fontWeight: "600" }}>
              {user.username}
            </span>
            <span style={{ 
              color: "rgba(255,255,255,0.7)", 
              fontSize: "0.75rem",
              padding: "0.25rem 0.5rem",
              background: "rgba(255, 255, 255, 0.15)",
              borderRadius: "4px"
            }}>
              {user.role}
            </span>
          </div>
          <button onClick={logout} className="logout-btn">
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
}
