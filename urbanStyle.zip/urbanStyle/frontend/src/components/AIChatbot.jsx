import { useState, useRef, useEffect } from "react";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";

export default function AIChatbot({ onClose }) {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Hello! I'm your AI assistant. I can help you analyze customer feedback, identify issues, suggest resolutions, and answer questions about your data. How can I help you today?",
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const { user } = useAuth();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = {
      role: "user",
      content: input,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const response = await api.post("/ai/chat", { question: input });
      
      const assistantMessage = {
        role: "assistant",
        content: response.data.response,
        timestamp: response.data.timestamp,
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage = {
        role: "assistant",
        content: "Sorry, I encountered an error. Please try again or rephrase your question.",
        timestamp: new Date().toISOString(),
        error: true,
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const quickQuestions = [
    "What are the main customer issues?",
    "How to resolve delivery complaints?",
    "What's the current satisfaction rate?",
    "Which stores need attention?",
  ];

  const handleQuickQuestion = (question) => {
    setInput(question);
  };

  return (
    <div className="ai-chatbot-container">
      <div className="ai-chatbot-header">
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <div className="ai-avatar">🤖</div>
          <div>
            <h3 style={{ margin: 0, fontSize: "1.1rem", fontWeight: "700" }}>AI Assistant</h3>
            <p style={{ margin: 0, fontSize: "0.75rem", color: "#64748b" }}>
              Powered by AI • Ask me anything
            </p>
          </div>
        </div>
        <button onClick={onClose} className="chat-close-btn">×</button>
      </div>

      <div className="ai-chatbot-messages">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`chat-message ${message.role} ${message.error ? "error" : ""}`}
          >
            <div 
              className="chat-message-content" 
              style={{ 
                whiteSpace: "pre-wrap",
                lineHeight: "1.7",
                fontFamily: "inherit"
              }}
            >
              {message.content}
            </div>
            <div className="chat-message-time">
              {new Date(message.timestamp).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </div>
          </div>
        ))}
        {loading && (
          <div className="chat-message assistant">
            <div className="chat-message-content">
              <div className="typing-indicator">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {messages.length === 1 && (
        <div className="quick-questions">
          <p style={{ fontSize: "0.875rem", color: "#64748b", marginBottom: "0.75rem" }}>
            Try asking:
          </p>
          <div className="quick-questions-grid">
            {quickQuestions.map((q, i) => (
              <button
                key={i}
                className="quick-question-btn"
                onClick={() => handleQuickQuestion(q)}
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      <form onSubmit={handleSend} className="ai-chatbot-input">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask me about customer feedback, issues, resolutions..."
          className="chat-input"
          disabled={loading}
        />
        <button type="submit" className="chat-send-btn" disabled={loading || !input.trim()}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="22" y1="2" x2="11" y2="13"></line>
            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
          </svg>
        </button>
      </form>
    </div>
  );
}

