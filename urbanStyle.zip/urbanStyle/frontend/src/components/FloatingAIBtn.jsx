import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AIChatbot from "./AIChatbot";

export default function FloatingAIBtn() {
  const [showChat, setShowChat] = useState(false);
  const navigate = useNavigate();

  return (
    <>
      {!showChat && (
        <button
          className="floating-ai-btn"
          onClick={() => {
            setShowChat(true);
          }}
          title="Open AI Assistant"
        >
          🤖
        </button>
      )}
      {showChat && (
        <div
          style={{
            position: "fixed",
            bottom: "2rem",
            right: "2rem",
            width: "400px",
            maxWidth: "90vw",
            zIndex: 2000,
            boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
            borderRadius: "16px",
            overflow: "hidden",
            background: "white",
          }}
        >
          <AIChatbot onClose={() => setShowChat(false)} />
        </div>
      )}
    </>
  );
}

