export default function FeedbackTable({ data }) {
  if (!data || data.length === 0) {
    return <p>No feedback data available.</p>;
  }

  return (
    <div className="table-container">
      <table className="table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Store</th>
            <th>Product</th>
            <th>Rating</th>
            <th>Comment</th>
            <th>Channel</th>
          </tr>
        </thead>
        <tbody>
          {data.map((f) => (
            <tr key={f.id}>
              <td>{f.createdAt || "N/A"}</td>
              <td>
                <span className="badge badge-info">{f.store}</span>
              </td>
              <td>{f.product || "General"}</td>
              <td>
                {f.rating >= 4 ? (
                  <span className="badge badge-success">{f.rating} ⭐</span>
                ) : f.rating === 3 ? (
                  <span className="badge badge-warning">{f.rating} ⭐</span>
                ) : (
                  <span className="badge badge-danger">{f.rating} ⭐</span>
                )}
              </td>
              <td style={{ maxWidth: "400px" }}>{f.comment}</td>
              <td>{f.channel || "Unknown"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
