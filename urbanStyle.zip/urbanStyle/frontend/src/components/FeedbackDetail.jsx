import { useState, useEffect } from "react";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";
import EmailComposer from "./EmailComposer";

export default function FeedbackDetail({ feedback, onClose }) {
  const [resolutions, setResolutions] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sendingFollowUp, setSendingFollowUp] = useState(false);
  const [followUpSent, setFollowUpSent] = useState(false);
  const [showEmailComposer, setShowEmailComposer] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    if (feedback) {
      fetchResolutions();
      checkFollowUps();
    }
  }, [feedback]);

  const checkFollowUps = async () => {
    try {
      const res = await api.get(`/followup/feedback/${feedback.id}`);
      if (res.data && res.data.length > 0) {
        setFollowUpSent(true);
      }
    } catch (error) {
      // Ignore errors
    }
  };

  const handleEmailSent = () => {
    setFollowUpSent(true);
    setShowEmailComposer(false);
  };

  const fetchResolutions = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/ai/resolutions/${feedback.id}`);
      setResolutions(res.data.resolutions);
    } catch (error) {
      console.error("Error fetching resolutions:", error);
    } finally {
      setLoading(false);
    }
  };

  if (!feedback) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Feedback Details</h2>
          <button onClick={onClose} className="modal-close-btn">×</button>
        </div>

        <div className="modal-body">
          <div className="feedback-detail-section">
            <h3>Feedback Information</h3>
            <div className="detail-grid">
              <div>
                <strong>Store:</strong> {feedback.store}
              </div>
              <div>
                <strong>Product:</strong> {feedback.product || "General"}
              </div>
              <div>
                <strong>Rating:</strong>{" "}
                <span className={`badge ${feedback.rating >= 4 ? "badge-success" : feedback.rating === 3 ? "badge-warning" : "badge-danger"}`}>
                  {feedback.rating} ⭐
                </span>
              </div>
              <div>
                <strong>Channel:</strong> {feedback.channel || "Unknown"}
              </div>
              <div>
                <strong>Date:</strong> {feedback.createdAt || "N/A"}
              </div>
              {feedback.category && (
                <div>
                  <strong>Category:</strong>{" "}
                  <span className="badge badge-info">{feedback.category}</span>
                </div>
              )}
              {feedback.customerName && (
                <div>
                  <strong>Customer Name:</strong> {feedback.customerName}
                </div>
              )}
              {feedback.customerEmail && (
                <div>
                  <strong>Customer Email:</strong> {feedback.customerEmail}
                </div>
              )}
            </div>
          </div>

          <div className="feedback-detail-section">
            <h3>Customer Comment</h3>
            <div className="comment-box">{feedback.comment}</div>
          </div>

          {feedback.suggestedResponse && (
            <div className="feedback-detail-section">
              <h3>AI Suggested Response</h3>
              <div className="suggested-response-box">{feedback.suggestedResponse}</div>
            </div>
          )}

          <div className="feedback-detail-section">
            <h3>AI-Powered Resolution Steps</h3>
            {loading ? (
              <div className="loading">
                <div className="spinner"></div>
              </div>
            ) : resolutions && resolutions.length > 0 ? (
              <ol className="resolutions-list">
                {resolutions.map((resolution, index) => (
                  <li key={index}>{resolution}</li>
                ))}
              </ol>
            ) : (
              <p style={{ color: "#64748b" }}>No resolutions available</p>
            )}
          </div>

          {feedback.customerEmail && (user?.role === "ADMIN" || user?.role === "MANAGER" || user?.role === "CX") && (
            <div className="feedback-detail-section">
              <h3>Send Follow-up Email</h3>
              {followUpSent ? (
                <div className="alert alert-success">
                  ✓ Follow-up email has been sent to {feedback.customerEmail}
                </div>
              ) : (
                <>
                  <p style={{ color: "#64748b", marginBottom: "1rem" }}>
                    Craft and send a personalized follow-up email using our AI-powered email composer. 
                    The AI will generate a professional email that you can edit before sending.
                  </p>
                  <button
                    className="btn btn-primary"
                    onClick={() => setShowEmailComposer(true)}
                  >
                    🤖 Compose Email with AI
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {showEmailComposer && (
        <div className="modal-overlay" onClick={() => setShowEmailComposer(false)} style={{ zIndex: 3000 }}>
          <div 
            className="modal-content" 
            style={{ maxWidth: "800px", width: "90%" }}
            onClick={(e) => e.stopPropagation()}
          >
            <EmailComposer
              feedback={feedback}
              onSend={handleEmailSent}
              onClose={() => setShowEmailComposer(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}

