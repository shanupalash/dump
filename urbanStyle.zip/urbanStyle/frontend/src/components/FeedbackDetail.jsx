import { useState, useEffect } from "react";
import api from "../api/api";

export default function FeedbackDetail({ feedback, onClose }) {
  const [resolutions, setResolutions] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (feedback) {
      fetchResolutions();
    }
  }, [feedback]);

  const fetchResolutions = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/ai/resolutions/${feedback.id}`);
      setResolutions(res.data.resolutions);
    } catch (error) {
      console.error("Error fetching resolutions:", error);
    } finally {
      setLoading(false);
    }
  };

  if (!feedback) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Feedback Details</h2>
          <button onClick={onClose} className="modal-close-btn">×</button>
        </div>

        <div className="modal-body">
          <div className="feedback-detail-section">
            <h3>Feedback Information</h3>
            <div className="detail-grid">
              <div>
                <strong>Store:</strong> {feedback.store}
              </div>
              <div>
                <strong>Product:</strong> {feedback.product || "General"}
              </div>
              <div>
                <strong>Rating:</strong>{" "}
                <span className={`badge ${feedback.rating >= 4 ? "badge-success" : feedback.rating === 3 ? "badge-warning" : "badge-danger"}`}>
                  {feedback.rating} ⭐
                </span>
              </div>
              <div>
                <strong>Channel:</strong> {feedback.channel || "Unknown"}
              </div>
              <div>
                <strong>Date:</strong> {feedback.createdAt || "N/A"}
              </div>
              {feedback.category && (
                <div>
                  <strong>Category:</strong>{" "}
                  <span className="badge badge-info">{feedback.category}</span>
                </div>
              )}
            </div>
          </div>

          <div className="feedback-detail-section">
            <h3>Customer Comment</h3>
            <div className="comment-box">{feedback.comment}</div>
          </div>

          {feedback.suggestedResponse && (
            <div className="feedback-detail-section">
              <h3>AI Suggested Response</h3>
              <div className="suggested-response-box">{feedback.suggestedResponse}</div>
            </div>
          )}

          <div className="feedback-detail-section">
            <h3>AI-Powered Resolution Steps</h3>
            {loading ? (
              <div className="loading">
                <div className="spinner"></div>
              </div>
            ) : resolutions && resolutions.length > 0 ? (
              <ol className="resolutions-list">
                {resolutions.map((resolution, index) => (
                  <li key={index}>{resolution}</li>
                ))}
              </ol>
            ) : (
              <p style={{ color: "#64748b" }}>No resolutions available</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

