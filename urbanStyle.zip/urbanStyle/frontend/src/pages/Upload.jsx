import { useState } from "react";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";

export default function Upload() {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const { user } = useAuth();

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      const ext = selectedFile.name.split(".").pop().toLowerCase();
      if (ext !== "csv" && ext !== "json") {
        setError("Please select a CSV or JSON file");
        setFile(null);
        return;
      }
      setFile(selectedFile);
      setError("");
      setMessage("");
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      setError("Please select a file");
      return;
    }

    setLoading(true);
    setError("");
    setMessage("");

    try {
      const formData = new FormData();
      formData.append("file", file);

      const res = await api.post("/feedback/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      setMessage(`Successfully uploaded ${res.data.count} feedback entries!`);
      setFile(null);
      // Reset file input
      document.getElementById("file-input").value = "";
    } catch (err) {
      setError(err.response?.data?.message || "Upload failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (user?.role !== "ADMIN") {
    return (
      <div className="card">
        <div className="alert alert-error">
          Access denied. Only administrators can upload feedback.
        </div>
      </div>
    );
  }

  return (
    <div>
      <div style={{ marginBottom: "2.5rem" }}>
        <h1>Upload Feedback Data</h1>
        <p style={{ color: "#64748b", fontSize: "1.1rem", marginTop: "0.5rem" }}>
          Import feedback data from Microsoft Forms or other sources
        </p>
      </div>
      
      <div className="card">
        <h2 className="card-title">Upload CSV or JSON File</h2>
        <p style={{ marginBottom: "1.5rem", color: "#666" }}>
          Upload feedback data exported from Microsoft Forms. The file should contain columns:
          store, channel, product, rating, comment, createdAt (optional)
        </p>

        <form onSubmit={handleUpload}>
          <div className="form-group">
            <label className="form-label">Select File (CSV or JSON)</label>
            <input
              id="file-input"
              type="file"
              accept=".csv,.json"
              onChange={handleFileChange}
              className="form-input"
              style={{ padding: "0.5rem" }}
            />
          </div>

          {file && (
            <div className="alert alert-info" style={{ marginBottom: "1rem" }}>
              Selected: {file.name} ({(file.size / 1024).toFixed(2)} KB)
            </div>
          )}

          {error && <div className="alert alert-error">{error}</div>}
          {message && <div className="alert alert-success">{message}</div>}

          <button 
            type="submit" 
            className="btn btn-primary"
            disabled={loading || !file}
          >
            {loading ? "Uploading..." : "Upload Feedback"}
          </button>
        </form>
      </div>

      <div className="card" style={{ marginTop: "2rem" }}>
        <h3 className="card-title">Load Test Data</h3>
        <p style={{ marginBottom: "1rem", color: "#666" }}>
          Load sample feedback data with customer emails for testing the follow-up email feature.
        </p>
        <button
          className="btn btn-secondary"
          onClick={async () => {
            try {
              const res = await api.post("/test-data/load");
              alert(`Successfully loaded ${res.data.count} test feedback entries!`);
            } catch (error) {
              alert(error.response?.data?.message || "Error loading test data");
            }
          }}
          disabled={user?.role !== "ADMIN"}
        >
          Load Test Data with Emails
        </button>
        {user?.role !== "ADMIN" && (
          <p style={{ marginTop: "0.5rem", fontSize: "0.875rem", color: "#dc3545" }}>
            Only administrators can load test data.
          </p>
        )}
      </div>

      <div className="card" style={{ marginTop: "2rem" }}>
        <h3 className="card-title">File Format Requirements</h3>
        <div style={{ marginTop: "1rem" }}>
          <h4 style={{ marginBottom: "0.5rem", color: "#333" }}>CSV Format:</h4>
          <pre style={{ 
            background: "#f8f9fa", 
            padding: "1rem", 
            borderRadius: "5px",
            overflow: "auto"
          }}>
{`store,channel,product,rating,comment,createdAt
Mumbai,Microsoft Form,T-Shirt,2,"delivery was late",2025-01-15
Delhi,QR Code,Jeans,4,"good quality product",2025-01-16`}
          </pre>
        </div>
        <div style={{ marginTop: "1.5rem" }}>
          <h4 style={{ marginBottom: "0.5rem", color: "#333" }}>JSON Format:</h4>
          <pre style={{ 
            background: "#f8f9fa", 
            padding: "1rem", 
            borderRadius: "5px",
            overflow: "auto"
          }}>
{`[
  {
    "store": "Mumbai",
    "channel": "Microsoft Form",
    "product": "T-Shirt",
    "rating": 2,
    "comment": "delivery was late",
    "createdAt": "2025-01-15"
  }
]`}
          </pre>
        </div>
      </div>
    </div>
  );
}
