import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";
import FeedbackDetail from "../components/FeedbackDetail";

export default function FollowUps() {
  const [followUps, setFollowUps] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedFeedback, setSelectedFeedback] = useState(null);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    fetchFollowUps();
    fetchStats();
  }, [user]);

  const fetchFollowUps = async () => {
    try {
      const res = await api.get("/followup");
      setFollowUps(res.data);
    } catch (error) {
      console.error("Error fetching follow-ups:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await api.get("/followup/stats");
      setStats(res.data);
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      sent: <span className="badge badge-info">Sent</span>,
      replied: <span className="badge badge-warning">Replied</span>,
      resolved: <span className="badge badge-success">Resolved</span>,
      closed: <span className="badge badge-primary">Closed</span>,
    };
    return badges[status] || <span className="badge">{status}</span>;
  };

  const handleViewFeedback = async (feedbackId) => {
    try {
      const res = await api.get(`/feedback/${feedbackId}`);
      setSelectedFeedback(res.data);
    } catch (error) {
      console.error("Error fetching feedback:", error);
    }
  };

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div>
      <div style={{ marginBottom: "2.5rem" }}>
        <h1>Customer Follow-ups</h1>
        <p style={{ color: "#64748b", fontSize: "1.1rem", marginTop: "0.5rem" }}>
          Track and manage customer follow-up communications
        </p>
      </div>

      {stats && (
        <div className="stats-grid" style={{ marginBottom: "2rem" }}>
          <div className="stat-card">
            <div className="stat-value">{stats.total}</div>
            <div className="stat-label">Total Follow-ups</div>
          </div>
          <div className="stat-card" style={{ borderLeftColor: "#17a2b8" }}>
            <div className="stat-value">{stats.sent}</div>
            <div className="stat-label">Sent</div>
          </div>
          <div className="stat-card" style={{ borderLeftColor: "#ffc107" }}>
            <div className="stat-value">{stats.replied}</div>
            <div className="stat-label">Replied</div>
          </div>
          <div className="stat-card" style={{ borderLeftColor: "#28a745" }}>
            <div className="stat-value">{stats.resolved}</div>
            <div className="stat-label">Resolved</div>
          </div>
        </div>
      )}

      <div className="card">
        <h2 className="card-title">Follow-up History</h2>

        {followUps.length === 0 ? (
          <p style={{ textAlign: "center", padding: "2rem", color: "#666" }}>
            No follow-ups sent yet. Send a follow-up from the Feedback page.
          </p>
        ) : (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Customer</th>
                  <th>Email</th>
                  <th>Store</th>
                  <th>Status</th>
                  <th>Sent By</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {followUps.map((fu) => (
                  <tr key={fu.id}>
                    <td>{new Date(fu.createdAt).toLocaleDateString()}</td>
                    <td>{fu.customerName || "N/A"}</td>
                    <td>{fu.customerEmail}</td>
                    <td>
                      <span className="badge badge-info">{fu.store}</span>
                    </td>
                    <td>{getStatusBadge(fu.status)}</td>
                    <td>{fu.sentBy} ({fu.sentByRole})</td>
                    <td>
                      <button
                        className="btn btn-secondary"
                        style={{ padding: "0.5rem 1rem", fontSize: "0.875rem" }}
                        onClick={() => handleViewFeedback(fu.feedbackId)}
                      >
                        View Feedback
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {selectedFeedback && (
        <FeedbackDetail
          feedback={selectedFeedback}
          onClose={() => setSelectedFeedback(null)}
        />
      )}
    </div>
  );
}

