import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";
import AIChatbot from "../components/AIChatbot";

export default function AIAssistant() {
  const [showChatbot, setShowChatbot] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  if (!user) {
    navigate("/login");
    return null;
  }

  return (
    <div style={{ position: "relative", minHeight: "80vh" }}>
      {showChatbot ? (
        <div style={{ 
          maxWidth: "900px", 
          margin: "2rem auto",
          background: "white",
          borderRadius: "16px",
          boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
          overflow: "hidden"
        }}>
          <AIChatbot onClose={() => setShowChatbot(false)} />
        </div>
      ) : (
        <div className="card" style={{ textAlign: "center", padding: "3rem" }}>
          <div style={{ fontSize: "4rem", marginBottom: "1rem" }}>🤖</div>
          <h2>AI Assistant</h2>
          <p style={{ color: "#64748b", marginBottom: "2rem" }}>
            Get instant insights about customer feedback, issues, and resolutions
          </p>
          <button className="btn btn-primary" onClick={() => setShowChatbot(true)}>
            Open AI Chat
          </button>
        </div>
      )}
    </div>
  );
}

