import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";
import Charts from "../components/Charts";

export default function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    fetchSummary();
  }, [user]);

  const fetchSummary = async () => {
    try {
      const res = await api.get("/analytics/summary");
      setSummary(res.data);
    } catch (error) {
      console.error("Error fetching summary:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  if (!summary) {
    return (
      <div className="card">
        <p>No data available. Please upload feedback data.</p>
      </div>
    );
  }

  const satisfactionRate = summary.total > 0 
    ? Math.round((summary.positiveCount / summary.total) * 100) 
    : 0;

  return (
    <div>
      <div style={{ marginBottom: "2.5rem" }}>
        <h1>Customer Feedback Dashboard</h1>
        <p style={{ color: "#64748b", fontSize: "1.1rem", marginTop: "0.5rem" }}>
          Real-time insights and analytics for customer feedback
        </p>
      </div>
      
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-value">{summary.total}</div>
          <div className="stat-label">Total Feedback</div>
        </div>
        <div className="stat-card" style={{ borderLeftColor: "#28a745" }}>
          <div className="stat-value">{summary.positiveCount}</div>
          <div className="stat-label">Positive Feedback</div>
        </div>
        <div className="stat-card" style={{ borderLeftColor: "#dc3545" }}>
          <div className="stat-value">{summary.negativeCount}</div>
          <div className="stat-label">Negative Feedback</div>
        </div>
        <div className="stat-card" style={{ borderLeftColor: "#ffc107" }}>
          <div className="stat-value">{satisfactionRate}%</div>
          <div className="stat-label">Satisfaction Rate</div>
        </div>
      </div>

      <div className="card">
        <h2 className="card-title">AI-Generated Summary</h2>
        <div style={{ 
          padding: "1.5rem", 
          background: "linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)",
          borderRadius: "12px",
          border: "1px solid #e2e8f0",
          lineHeight: "1.8", 
          color: "#475569",
          fontSize: "1.05rem"
        }}>
          {summary.summary}
        </div>
      </div>

      <Charts summary={summary} />
    </div>
  );
}
