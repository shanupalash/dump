import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const [form, setForm] = useState({ username: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { setUser } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await api.post("/auth/login", form);
      setUser(res.data);
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ 
      display: "flex", 
      justifyContent: "center", 
      alignItems: "center", 
      minHeight: "85vh",
      background: "linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)"
    }}>
      <div className="card" style={{ 
        width: "100%", 
        maxWidth: "480px",
        boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)"
      }}>
        <div style={{ textAlign: "center", marginBottom: "2.5rem" }}>
          <div style={{ 
            fontSize: "3rem", 
            marginBottom: "1rem",
            background: "linear-gradient(135deg, #1e3c72 0%, #2a5298 50%, #7e8ba3 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text"
          }}>
            👔
          </div>
          <h1 style={{ 
            marginBottom: "0.5rem", 
            fontSize: "2rem",
            background: "linear-gradient(135deg, #1e3c72 0%, #2a5298 50%, #7e8ba3 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text"
          }}>
            UrbanStyle
          </h1>
          <p style={{ color: "#64748b", fontSize: "1rem", fontWeight: "500" }}>
            Feedback Management Portal
          </p>
        </div>
        <form onSubmit={handleLogin}>
          <div className="form-group">
            <label className="form-label">Username</label>
            <input
              type="text"
              className="form-input"
              placeholder="Enter your username"
              value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              className="form-input"
              placeholder="Enter your password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              required
            />
          </div>
          {error && <div className="alert alert-error">{error}</div>}
          <button 
            type="submit" 
            className="btn btn-primary" 
            style={{ width: "100%", marginTop: "0.5rem" }}
            disabled={loading}
          >
            {loading ? "Logging in..." : "Sign In"}
          </button>
        </form>
        <div style={{ 
          marginTop: "2rem", 
          padding: "1.5rem", 
          background: "linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)", 
          borderRadius: "12px",
          border: "1px solid #e2e8f0"
        }}>
          <p style={{ fontSize: "0.875rem", color: "#475569", marginBottom: "0.75rem", fontWeight: "600" }}>
            Demo Credentials
          </p>
          <div style={{ fontSize: "0.8125rem", color: "#64748b", lineHeight: "1.8" }}>
            <div style={{ marginBottom: "0.5rem" }}>
              <strong style={{ color: "#1e293b" }}>Admin:</strong> admin / admin123
            </div>
            <div style={{ marginBottom: "0.5rem" }}>
              <strong style={{ color: "#1e293b" }}>CX Lead:</strong> cxlead / cx123
            </div>
            <div>
              <strong style={{ color: "#1e293b" }}>Manager:</strong> manager1 / manager123
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
