import { useEffect, useState } from "react";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export default function FeedbackList() {
  const [feedback, setFeedback] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ store: "", rating: "", search: "" });
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    fetchFeedback();
  }, [user]);

  const fetchFeedback = async () => {
    try {
      const res = await api.get("/feedback");
      setFeedback(res.data);
    } catch (error) {
      console.error("Error fetching feedback:", error);
    } finally {
      setLoading(false);
    }
  };

  const getRatingBadge = (rating) => {
    if (rating >= 4) return <span className="badge badge-success">{rating} ⭐</span>;
    if (rating === 3) return <span className="badge badge-warning">{rating} ⭐</span>;
    return <span className="badge badge-danger">{rating} ⭐</span>;
  };

  const getSentimentColor = (rating) => {
    if (rating >= 4) return "#28a745";
    if (rating === 3) return "#ffc107";
    return "#dc3545";
  };

  const filteredFeedback = feedback.filter((f) => {
    if (filter.store && f.store !== filter.store) return false;
    if (filter.rating && f.rating !== Number(filter.rating)) return false;
    if (filter.search && !f.comment.toLowerCase().includes(filter.search.toLowerCase())) return false;
    return true;
  });

  const stores = [...new Set(feedback.map((f) => f.store))].sort();

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div>
      <div style={{ marginBottom: "2.5rem" }}>
        <h1>Customer Feedback</h1>
        <p style={{ color: "#64748b", fontSize: "1.1rem", marginTop: "0.5rem" }}>
          View and filter all customer feedback entries
        </p>
      </div>

      <div className="card" style={{ marginBottom: "2rem" }}>
        <h2 className="card-title">Filters</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1rem" }}>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Search Comments</label>
            <input
              type="text"
              className="form-input"
              placeholder="Search..."
              value={filter.search}
              onChange={(e) => setFilter({ ...filter, search: e.target.value })}
            />
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Store</label>
            <select
              className="form-select"
              value={filter.store}
              onChange={(e) => setFilter({ ...filter, store: e.target.value })}
            >
              <option value="">All Stores</option>
              {stores.map((store) => (
                <option key={store} value={store}>
                  {store}
                </option>
              ))}
            </select>
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Rating</label>
            <select
              className="form-select"
              value={filter.rating}
              onChange={(e) => setFilter({ ...filter, rating: e.target.value })}
            >
              <option value="">All Ratings</option>
              <option value="5">5 Stars</option>
              <option value="4">4 Stars</option>
              <option value="3">3 Stars</option>
              <option value="2">2 Stars</option>
              <option value="1">1 Star</option>
            </select>
          </div>
        </div>
      </div>

      <div className="card">
        <div style={{ marginBottom: "1rem", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2 className="card-title" style={{ marginBottom: 0 }}>
            Feedback List ({filteredFeedback.length})
          </h2>
        </div>

        {filteredFeedback.length === 0 ? (
          <p style={{ textAlign: "center", padding: "2rem", color: "#666" }}>
            No feedback found matching your filters.
          </p>
        ) : (
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Store</th>
                  <th>Product</th>
                  <th>Rating</th>
                  <th>Comment</th>
                  <th>Channel</th>
                </tr>
              </thead>
              <tbody>
                {filteredFeedback.map((f) => (
                  <tr key={f.id}>
                    <td>{f.createdAt || "N/A"}</td>
                    <td>
                      <span className="badge badge-info">{f.store}</span>
                    </td>
                    <td>{f.product || "General"}</td>
                    <td>{getRatingBadge(f.rating)}</td>
                    <td style={{ maxWidth: "400px" }}>{f.comment}</td>
                    <td>{f.channel || "Unknown"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

