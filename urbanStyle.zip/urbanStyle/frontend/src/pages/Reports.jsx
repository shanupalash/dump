import { useEffect, useState } from "react";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { Bar, Doughnut, Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export default function Reports() {
  const [analytics, setAnalytics] = useState(null);
  const [storeData, setStoreData] = useState(null);
  const [productData, setProductData] = useState(null);
  const [ratingData, setRatingData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
    fetchReports();
  }, [user]);

  const fetchReports = async () => {
    try {
      const [summaryRes, storesRes, productsRes, ratingsRes] = await Promise.all([
        api.get("/analytics/summary"),
        user.role !== "MANAGER" ? api.get("/analytics/stores") : Promise.resolve({ data: null }),
        user.role !== "MANAGER" ? api.get("/analytics/products") : Promise.resolve({ data: null }),
        api.get("/analytics/ratings"),
      ]);

      setAnalytics(summaryRes.data);
      setStoreData(storesRes.data);
      setProductData(productsRes.data);
      setRatingData(ratingsRes.data);
    } catch (error) {
      console.error("Error fetching reports:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
      </div>
    );
  }

  const themeChartData = analytics?.themes ? {
    labels: Object.keys(analytics.themes),
    datasets: [
      {
        label: "Theme Frequency",
        data: Object.values(analytics.themes),
        backgroundColor: [
          "#1e3c72",
          "#2a5298",
          "#667eea",
          "#764ba2",
          "#4facfe",
          "#43e97b",
          "#fa709a",
        ],
        borderColor: [
          "#2a5298",
          "#3d6bb3",
          "#764ba2",
          "#8b5fbf",
          "#00f2fe",
          "#38f9d7",
          "#fee140",
        ],
        borderWidth: 2,
        borderRadius: 8,
      },
    ],
  } : null;

  const ratingChartData = ratingData ? {
    labels: ["1 Star", "2 Stars", "3 Stars", "4 Stars", "5 Stars"],
    datasets: [
      {
        label: "Rating Distribution",
        data: [
          ratingData[1] || 0,
          ratingData[2] || 0,
          ratingData[3] || 0,
          ratingData[4] || 0,
          ratingData[5] || 0,
        ],
        backgroundColor: [
          "#dc3545",
          "#fd7e14",
          "#ffc107",
          "#20c997",
          "#28a745",
        ],
        borderColor: [
          "#c82333",
          "#e55a00",
          "#ffb300",
          "#17a2b8",
          "#218838",
        ],
        borderWidth: 2,
      },
    ],
  } : null;

  const storeChartData = storeData ? {
    labels: Object.keys(storeData),
    datasets: [
      {
        label: "Total Feedback",
        data: Object.values(storeData).map((s) => s.total),
        backgroundColor: "#1e3c72",
        borderColor: "#2a5298",
        borderWidth: 2,
        borderRadius: 8,
      },
      {
        label: "Negative Feedback",
        data: Object.values(storeData).map((s) => s.negative),
        backgroundColor: "#dc3545",
        borderColor: "#c82333",
        borderWidth: 2,
        borderRadius: 8,
      },
    ],
  } : null;

  const productChartData = productData ? {
    labels: Object.keys(productData),
    datasets: [
      {
        label: "Average Rating",
        data: Object.values(productData).map((p) => parseFloat(p.avgRating)),
        backgroundColor: "#1e3c72",
        borderColor: "#2a5298",
        borderWidth: 2,
        borderRadius: 8,
      },
    ],
  } : null;

  return (
    <div>
      <div style={{ marginBottom: "2.5rem" }}>
        <h1>Analytics & Reports</h1>
        <p style={{ color: "#64748b", fontSize: "1.1rem", marginTop: "0.5rem" }}>
          Comprehensive analytics and insights for stakeholders
        </p>
      </div>

      {analytics && (
        <div className="card" style={{ marginBottom: "2rem" }}>
          <h2 className="card-title">Executive Summary</h2>
          <div style={{ 
            padding: "1.5rem", 
            background: "linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)",
            borderRadius: "12px",
            border: "1px solid #e2e8f0",
            lineHeight: "1.8", 
            color: "#475569",
            fontSize: "1.05rem",
            marginBottom: "1.5rem"
          }}>
            {analytics.summary}
          </div>
          <div className="stats-grid" style={{ marginTop: "1.5rem", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))" }}>
            <div style={{ 
              padding: "1rem", 
              background: "white", 
              borderRadius: "10px",
              border: "1px solid #e2e8f0"
            }}>
              <div style={{ fontSize: "0.875rem", color: "#64748b", marginBottom: "0.5rem", fontWeight: "600" }}>
                Total Feedback
              </div>
              <div style={{ fontSize: "1.75rem", fontWeight: "700", color: "#1e293b" }}>
                {analytics.total}
              </div>
            </div>
            <div style={{ 
              padding: "1rem", 
              background: "white", 
              borderRadius: "10px",
              border: "1px solid #e2e8f0"
            }}>
              <div style={{ fontSize: "0.875rem", color: "#64748b", marginBottom: "0.5rem", fontWeight: "600" }}>
                Positive
              </div>
              <div style={{ fontSize: "1.75rem", fontWeight: "700", color: "#28a745" }}>
                {analytics.positiveCount} (
                {analytics.total > 0
                  ? Math.round((analytics.positiveCount / analytics.total) * 100)
                  : 0}
                %)
              </div>
            </div>
            <div style={{ 
              padding: "1rem", 
              background: "white", 
              borderRadius: "10px",
              border: "1px solid #e2e8f0"
            }}>
              <div style={{ fontSize: "0.875rem", color: "#64748b", marginBottom: "0.5rem", fontWeight: "600" }}>
                Negative
              </div>
              <div style={{ fontSize: "1.75rem", fontWeight: "700", color: "#dc3545" }}>
                {analytics.negativeCount} (
                {analytics.total > 0
                  ? Math.round((analytics.negativeCount / analytics.total) * 100)
                  : 0}
                %)
              </div>
            </div>
          </div>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))", gap: "1.5rem" }}>
        {themeChartData && (
          <div className="chart-container">
            <h3 className="card-title">Key Themes</h3>
            <Bar
              data={themeChartData}
              options={{
                responsive: true,
                plugins: {
                  legend: { display: false },
                  title: { display: false },
                },
              }}
            />
          </div>
        )}

        {ratingChartData && (
          <div className="chart-container">
            <h3 className="card-title">Rating Distribution</h3>
            <Doughnut
              data={ratingChartData}
              options={{
                responsive: true,
                plugins: {
                  legend: { position: "bottom" },
                },
              }}
            />
          </div>
        )}
      </div>

      {storeChartData && user.role !== "MANAGER" && (
        <div className="chart-container" style={{ marginTop: "1.5rem" }}>
          <h3 className="card-title">Store Performance</h3>
          <Bar
            data={storeChartData}
            options={{
              responsive: true,
              plugins: {
                legend: { position: "top" },
              },
            }}
          />
        </div>
      )}

      {productChartData && user.role !== "MANAGER" && (
        <div className="chart-container" style={{ marginTop: "1.5rem" }}>
          <h3 className="card-title">Product Performance</h3>
          <Bar
            data={productChartData}
            options={{
              responsive: true,
              plugins: {
                legend: { display: false },
              },
              scales: {
                y: {
                  beginAtZero: true,
                  max: 5,
                },
              },
            }}
          />
        </div>
      )}

      {storeData && user.role !== "MANAGER" && (
        <div className="card" style={{ marginTop: "2rem" }}>
          <h2 className="card-title">Store Analysis</h2>
          <div className="table-container">
            <table className="table">
              <thead>
                <tr>
                  <th>Store</th>
                  <th>Total Feedback</th>
                  <th>Positive</th>
                  <th>Negative</th>
                  <th>Avg Rating</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(storeData).map(([store, data]) => (
                  <tr key={store}>
                    <td><strong>{store}</strong></td>
                    <td>{data.total}</td>
                    <td><span className="badge badge-success">{data.positive}</span></td>
                    <td><span className="badge badge-danger">{data.negative}</span></td>
                    <td>{data.avgRating}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

